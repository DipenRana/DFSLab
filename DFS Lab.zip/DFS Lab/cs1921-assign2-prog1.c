/*-----------------------------------
Name: Anoop Kumar
Roll number: CS1921
Date: 11/10/2019
Program description: Assignment 2 Program 1
Acknowledgements:
------------------------------------*/

#include<sys/time.h>
#include<stdio.h>
#define GAP(start, end) ((end.tv_usec-start.tv_usec)+(end.tv_sec-start.tv_sec)*1000000)

unsigned long  int binomialCoeff(unsigned long  int n, unsigned long  int k)  
{  
    int res = 1;  
    if(k>n)
		return 0;
    // Since C(n, k) = C(n, n-k)  
    if ( k > n - k )  
        k = n - k;  
    // Calculate value of  
    // [n * (n-1) *---* (n-k+1)] / [k * (k-1) *----* 1]  
    for (unsigned long  int i = 0; i < k; ++i)  
    {  
        res *= (n - i);  
        res /= (i + 1);  
    }  
    return res;  
}


void main(){
    struct timeval start_time, end_time;
    /* START OF BLOCK */
    unsigned long  int n, N, e, E, e_choose_i, E_e_choose_N_i, E_choose_N;
    float p_value = 0;
    unsigned long  int i, var1, var2, var3, var4; // Temporary variables
    fscanf(stdin, "%lu%lu%lu%lu", &n, &N, &e, &E);
    gettimeofday(&start_time, NULL);
	for(i = n; i <= N; i++){
		e_choose_i = binomialCoeff(e,i);		
		E_e_choose_N_i = binomialCoeff(E-e,N-i);
		p_value += e_choose_i*E_e_choose_N_i;
    }
	E_choose_N = binomialCoeff(E,N);
	if(E_choose_N != 0)
	{
		p_value /= E_choose_N;
	}
	else
		p_value = 0;
    /* END OF BLOCK */
    gettimeofday(&end_time, NULL);
    printf("p-value = %f (%d microseconds)", p_value, (int) GAP(start_time, end_time));
}