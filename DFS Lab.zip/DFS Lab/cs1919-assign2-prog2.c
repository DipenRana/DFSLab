/*-----------------------------------
Name:Akhil Agrawal
Roll number:CS1919
Date:11/10/2019
Program description:cross probability
Acknowledgements:
------------------------------------*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int sizep1=0,sizep2=0,sizec1=0,sizec2=0;
//global varialbe for sizes
int min(int x,int y){
  //utility function for finding minimum index
  if(x<y)return x;
  else return y;
}
//the function for input strings in char type
char* scan(char *string)
{
    int c; //as getchar() returns `int`
    string = malloc(sizeof(char)); //allocating memory
    string[0]='\0';

    for(int i=0; (c=getchar())!='\n' && c != EOF ; i++){
        string = realloc(string, (i+2)*sizeof(char)); //reallocating memory
        string[i] = (char) c; //type casting `int` to `char`
        string[i+1] = '\0'; //inserting null character at the end
    }
    return string;
}

int startCheck(char* p,char* c,int sizep,int sizec){//if return size c complete match
    int x=min(sizep,sizec);
    for(int i=0;i<x;i++){
      if(p[i]==c[i])continue;
      else return i;
    }
    return x;
}

int endCheck(char* p,char* c,int sizep,int sizec){//if -1 complete match
    int x=min(sizep,sizec);
    for(int i=0;i<x;i++){
      if(p[sizep-1-i]==c[sizec-1-i])continue;
      else return sizec-1-i;
    }
    if(x==0)return 0;
    return sizec-x-1;
}
int main(){

  float i;//probability
  char c;//char for /n
  scanf("%f%c",&i,&c);

  char *p1,*p2,*c1,*c2;
  p1=scan(p1);sizep1=strlen(p1);
  p2=scan(p2);sizep2=strlen(p2);
  c1=scan(c1);sizec1=strlen(c1);
  c2=scan(c2);sizec2=strlen(c2);
  if(i==0.0f){
    printf("INFEASIBLE");
    return 0;
  }
  int a1=startCheck(p1,c1,sizep1,sizec1);
  int a2=endCheck(p2,c1,sizep2,sizec1);
  //printf("%d %d\n",a1,a2);
  int b1=startCheck(p2,c2,sizep1,sizec2);
  int b2=endCheck(p1,c2,sizep2,sizec2);
  //printf("%d %d",b1,b2);
  int count=0;
  if(a1==a2+1)count++;
  if(b1==b2+1)count++;

  if(count==0){
    printf("INFEASIBLE");
    return 0;
  }else {
    printf("%d %d",a1,b1);
  }

  free(p1);free(p2);free(c1);free(c2);
  //freeing up the allocated memories
  return 0;
}
