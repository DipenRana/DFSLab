/*-----------------------------------
Name: Dipen Rana    
Roll number: CS1901
Date: 11/10/2019
Program description: Assignment 2 Program 2:crossover probability
Acknowledgements:
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* input(char *p) {
    int len = 0;
    char c;
    p = (char *)malloc(sizeof(char));
    scanf("%c", &c );
    while(c !='\n'){
        p[len] = c;
        realloc(p, (len+1)*sizeof(char));
        len++;
        scanf("%c", &c );
    }
    p[len] = '\0';
    return p;
}

void print(char *p) {
    int i = 0;
    while(p[i]!='\0'){
        printf("%c",p[i++]);
    }
}

void freePtr(char *p,char *q,char *r, char *s) {
    free(p);
    free(q);
    free(r);
    free(s);
}

int main() {
    char *parent_1, *parent_2, *child_1, *child_2,c;
    float prob;
    int lenP1,lenP2,lenC1,lenC2;
    int x, y;

    printf("Enter probability value.\n");
    scanf("%f", &prob);
    printf("Enter two parent chromosomes and two child chromosomes\n");
    scanf("%c", &c );

    parent_1 = input(parent_1);
    parent_2 = input(parent_2);
    child_1 = input(child_1);
    child_2 = input(child_2);

    lenP1 = strlen(parent_1);
    lenP2 = strlen(parent_2);
    lenC1 = strlen(child_1);
    lenC2 = strlen(child_2);
    
    if(lenP1 + lenP2 != lenC1 + lenC2) {
        printf("INFEASIBLE");
        freePtr(parent_1,parent_2,child_1,child_2);
        return 0;
    }
    
    if(lenC1 == 0) {
        if(!strncmp(parent_2,child_2,lenP2) && !strncmp(parent_1,child_2+lenP2,lenP1))
            printf("0 %d",lenP2);
        else
            printf("INFISEABLE");
        
        freePtr(parent_1,parent_2,child_1,child_2);
        return 0;    
    } else if(lenC2 == 0) {
        if(!strncmp(parent_1,child_1,lenP1) && !strncmp(parent_2,child_1+lenP1,lenP2))
            printf("%d 0",lenP1);
        else
            printf("INFISEABLE");
        freePtr(parent_1,parent_2,child_1,child_2);
        return 0;
    }

    if(prob == 0) {
        if(!strcmp(parent_1, child_1) && !strcmp(parent_2, child_2)) {
            printf("%d %d",lenP1,lenP2);
        } else {
            printf("INFEASIBLE");
        }
        freePtr(parent_1,parent_2,child_1,child_2);
        return 0;
    } else if(prob == 1) {
        if(!strcmp(parent_1, child_1) && !strcmp(parent_2, child_2)) {
            printf("INFEASIBLE");
            freePtr(parent_1,parent_2,child_1,child_2);
            return 0;
        }
    }

    x = 0;      //number of common chars in P1 and C1
    int i = 0;
    while(parent_1[i] == child_1[i] && i < lenP1){  
            x++;    i++;
    }

    y = 0;      //number of common chars in P2 and C2
    i = 0;
    while(parent_2[i] == child_2[i] && i < lenP2){
            y++;    i++;
    }

    //Calculating the lenght of each part in A B and C D (parents) and childs A D and C B

    if(y < lenC2-(lenP1-x)) {
        printf("INFEASIBLE");
        freePtr(parent_1,parent_2,child_1,child_2);
        return 0;
    } else{
        int p,q;
        int crosx,crosy;
        for(int i = x; i>0; i--){
            crosx = lenP1 - x;
            p = strncmp(parent_1+x, child_2+(lenC2-crosx), crosx);
            crosy = lenC1 - x;
            q = strncmp(child_1+x,parent_2+(lenP2-crosy),crosy);
            if(!p && !q) {
                printf("%d %d",x, lenP2-crosy);
                freePtr(parent_1,parent_2,child_1,child_2);
                return 0;
            }
        }
    }

    printf("INFEASIBLE");

    return 0;
}