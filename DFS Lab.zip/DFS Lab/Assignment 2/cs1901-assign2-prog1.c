/*-----------------------------------
Name: Dipen Rana    
Roll number: CS1901
Date: 11/10/2019
Program description: Assignment 2 Program 1: Optimization problem of calculating the p value.
Acknowledgements:
------------------------------------*/

#include<sys/time.h>
#include<stdio.h>

#define GAP(start, end) ((end.tv_usec-start.tv_usec)+(end.tv_sec-start.tv_sec)*1000000)

void main(){

struct timeval start_time, end_time;
gettimeofday(&start_time, NULL);
/* START OF BLOCK */
long int n, N, e, E;
long int e_choose_n, E_e_choose_N_n, E_choose_N;
float p_value = 0;
long int i, var1, var2, var3, var4; // Temporary variables

fscanf(stdin, "%ld%ld%ld%ld", &n, &N, &e, &E);

if (e >= n) {       //compute e choose n
    var2 = 1;
    var3 = 1;
    for(var1 = 1, var4 = 2; var4 <= e; var4++)
    {
        var1 = var1 * var4; 
        if(var4 == n)
            var2 = var1;
        else if(var4 == e-n)
            var3 = var1;
    }
    //printf("Var1 = %ld, var2 = %ld, var3 =%ld\n", var1, var2, var3);
    e_choose_n = var1/(var2*var3);
} else {
    e_choose_n = 0;
}

//printf("e_choose_n =%ld\n", e_choose_n);

if (E-e >= N-n) {       //Compute E-e choose N-n
    var2 = 1;
    var3 = 1;
    for(var1 = 1, var4 = 2; var4 <= E-e; var4++)
    {
        var1 = var1 * var4; 
        if(var4 == N-n)
            var2 = var1;
        else if(var4 == (E-e)-(N-n))
            var3 = var1;
    }
    
    //printf("Var1 = %ld, var2 = %ld, var3 =%ld\n", var1, var2, var3);
    E_e_choose_N_n = var1/(var2*var3);
} else {
    E_e_choose_N_n = 0;
}
//printf("E-e_choose_N-n =%ld\n", E_e_choose_N_n);

p_value = e_choose_n * E_e_choose_N_n;

for(i = 1; i <= N-n && n+i <= e; i++){      //no need to compute e choose n every time. can reduce time using the following formula.

    e_choose_n = (e-n-i+1) * e_choose_n / (n + i);

    E_e_choose_N_n = ((N-n) - i + 1) * E_e_choose_N_n / ((E - e) - (N - n) + i);

    p_value += e_choose_n*E_e_choose_N_n;
}

if (E >= N) {      // compute E choose N
    var2 = 1;
    var3 = 1;
    for(var1 = 1, var4 = 2; var4 <= E; var4++)
    {
        var1 = var1 * var4; 
        if(var4 == N)
            var2 = var1;
        else if(var4 == E-N)
            var3 = var1;
    }
    E_choose_N = var1/(var2*var3); 
} else {
    E_choose_N =  1;        //since we are dividing with E_choose_N.
}

p_value /= E_choose_N;
/* END OF BLOCK */
gettimeofday(&end_time, NULL);
printf("p-value = %f (%d microseconds)", p_value, (int) GAP(start_time, end_time));
}