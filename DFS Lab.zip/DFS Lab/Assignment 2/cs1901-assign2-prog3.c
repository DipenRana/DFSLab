/*-----------------------------------
Name: Dipen Rana    
Roll number: CS1901
Date: 17/10/2019
Program description: Assignment 2 Program 3: List multiplication.
Acknowledgements:
------------------------------------*/

#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>

#define MAX 1000

int main() {

    long int mulA[MAX] = {0};
    long int mulB[MAX] = {0};
    long int arrA[MAX];
    long int arrB[MAX];
	long int n = 0, m = 0, k1 = 0, k2 = 0; 	
 	char par;


 	printf("Enter positive integer numbers separeted by space.\n");

	do {
		scanf("%d%c",&arrA[n],&par);
		n++;
	} while (par != '\n');

    do {
		scanf("%d%c",&arrB[m],&par);
		m++;
	} while (par != '\n');

// Mutiplying array list A
    while (arrA[0] > 0)
    {
        long int rem;
        rem = arrA[0] % 10;
        mulA[k1++] = rem;
        arrA[0] /= 10; 
    }

    for (long int i = 1; i < n; i++)
    {
        long int cry = 0, temp;
        for (long int j = 0; j < k1; j++)
        {
            temp = mulA[j] * arrA[i] + cry;
            mulA[j] = temp % 10;
            cry = temp / 10;
        }

        long int rem;
        while (cry > 0) {
            
            rem = cry % 10;
            mulA[k1++] = rem;
            cry /= 10; 
        }
    }
    printf("Here k1=%d\n",k1);
    //printing mulA
    for (long int i = k1-1; i > 0; i--)
        printf("%d", mulA[i]);
    printf("\n");

// Mutiplying array list B
    k2 = 0;
    while (arrB[0] > 0)
    {
        long int rem;
        rem = arrB[0] % 10;
        mulB[k2++] = rem;
        arrB[0] /= 10; 
    }

    for (long int i = 1; i < m; i++)
    {
        long int cry = 0, temp;
        for (long int j = 0; j < k2; j++)
        {
            temp = mulB[j] * arrB[i] + cry;
            mulB[j] = temp % 10;
            cry = temp / 10;
        }

        long int rem;
        while (cry > 0) {
            
            rem = cry % 10;
            mulB[k2++] = rem;
            cry /= 10; 
        }
    }

    //printing mulB
    for (long int i = k2-1; i > 0; i--)
        printf("%d", mulB[i]);
    printf("\n");
  
    if (k1 > k2) {
        printf("L1");
    } else if (k2 > k1){
        printf("L2");
    } else {
        m = k1;
        while (mulA[m] == mulB[m] && m >= 0)
            m--;

        if (m == -1)
            printf("L1 L2");
        else {
            if (mulB[m] > mulA[m])
                printf("L2");
            else
                printf("L1");   
        }
    }

    return 0;
}