import sys
import time

n = int(input("Enter number of integers."))
listint = []
for i in range(n):
    ele = int(input(f'{i+1}. '))
    listint.append(ele)

sum = 0
start = time.time()
for ele in listint:
    sum = sum + ele
end = time.time()

print(f'Time taken to sum the numbers is {end - start} sec ')
