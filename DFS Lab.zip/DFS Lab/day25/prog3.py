import sys


b= []

n = int(input("Enter number of lines"))


for i in range(0,n-1,1):
	x = ''
	k = 0
	while k < (n-i):
		x = x + ' '
		k += 1
	for j in range(n-i,n+i-1):
		x = x + '*'
	print(x)
for i in range(n-1,0,-1):
	x = ''
	k = 0
	while k < n - i:
		x = x + ' '
		k += 1
	for j in range(n-i,n+i-1):
		x = x + '*'
	print(x)




#while (1):
#	x = sys.stdin.readline()
#	if(x[0] == '\n'):
#		break
#	b.extend(x[:-1].split(" "))
#	print(b)
