import sys

def calcArea(a, b, c):
    s = 0.5*(a+b+c)
    A = (s*(s-a)*(s-b)*(s-c))**0.5
    return A

list = [int(x) for x in input().split()]
x1, y1, x2, y2, x3, y3 = list
print(list)
d1 = ((x2-x1)**2+(y2-y1)**2)**0.5
d2 = ((x3-x1)**2+(y3-y1)**2)**0.5
d3 = ((x3-x2)**2+(y3-y2)**2)**0.5

area = calcArea(d1,d2,d3)
print(f"Area ={area}")
if area == int(area):
    print("Heron Triangle")
else:
    print("Not Heron Triangle")
