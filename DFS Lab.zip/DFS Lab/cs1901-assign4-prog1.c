#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int tab, tabspacecount;
    int comma,semicolon, pipe, single_quote_fwd, single_quote_bkd,
        double_quote_fwd, double_quote_bkd, open_bracket, close_bracket,
        fwd_slash, bck_slash;
} DELIMITER_COUNT;

void checkDelimiter(DELIMITER_COUNT *cnt, char ch) {
    if(ch == ' '){
        cnt->tab = cnt->tab +1;
    } else if(ch == ',') {
        cnt->comma = cnt->comma +1;
    } else if(ch == ';') {
        cnt->semicolon = cnt->semicolon +1;
    } else if(ch == '|') {
        cnt->pipe = cnt->pipe +1;
    } else if(ch == '\'') {
        cnt->single_quote_fwd = cnt->single_quote_fwd +1;
    } else if(ch == '\"') {
       cnt->double_quote_fwd = cnt->double_quote_fwd +1;
    } else if(ch == '/') {
        cnt->fwd_slash = cnt->fwd_slash +1;
    }  else if(ch == '\\') {
        cnt->bck_slash = cnt->bck_slash +1;
    } else if(ch == '{') {
        cnt->open_bracket = cnt->open_bracket +1;
    } else if(ch == '}') {
        cnt->close_bracket = cnt->close_bracket +1;
    }
}

void initialize_Count(DELIMITER_COUNT *count) {
    count->tab = 0;
    count->tabspacecount = 0;
    count->comma = 0;
    count->semicolon = 0;
    count->single_quote_fwd = 0;
    count->double_quote_fwd = 0;
    count->pipe = 0;
    count->open_bracket = 0;
    count->close_bracket = 0;
    count->fwd_slash = 0;
    count->bck_slash = 0;
}

int isDelimiter(char ch) {
    if(ch == ' ' ||ch == ',' ||ch == ';' ||ch == '\'' ||ch == '\"' ||ch == '/' ||ch == '\\' ||ch == '|' ||
        ch == '{' ||ch == '}' )
        return 1;
    else
        return 0;
    
}

int isRepeating(int arr[], int size) 
{ 
  int i; 
  for (i = 0; i < size-1; i++) 
  { 
    for (int j = i+1; j < size; j++)
    {
        if(arr[i]==arr[j])
            return 1;
    }
  } 
  return 0;
} 


int main(int ac, char *av[]) {
    FILE *fptr, *outptr;
    DELIMITER_COUNT *count;
    int n;
    char c;
    int spaceCount[10], freq[10];


    for (int i = 0; i < 10; i++)
    {
        spaceCount[i] = 0;
        freq[i] = 0;
    }
    

    count = (DELIMITER_COUNT *)malloc(sizeof(DELIMITER_COUNT));
    printf("%s %s \n",av[1],av[2]);

    fptr =  fopen(av[1], "r");
    if (fptr == NULL)
    {
        printf("File is not available \n");
    }
    outptr = fopen(av[2], "w"); 
    if (outptr == NULL)
        printf("Cannot open file  \n"); 

    initialize_Count(count);

    printf("printing input file \n");

    int x = 0;
    while((c= fgetc(fptr)) != EOF) {
        printf("%c", c);
        checkDelimiter(count, c);
        if(c == ' '){
            int j = 1,i;
            while ((c= fgetc(fptr)) != EOF && c == ' ')
            {
                j++;
            }
            printf("\n j = %d  ", j);
            for ( i = 0; i < x; i++)
            {
                if(spaceCount[i]== j)
                {    freq[i]++;
                    break;
                }
            }
            if(i == x)
            {    spaceCount[i] = j;
                freq[i]++;
                x++;
            }
            
            
        }
    }

    char delimiter ;

    int max1 = -1;
    int max_count = 0;
    printf("Count(,) = %d", count->comma);
    printf("Count(tab) = %d", count->tab);
    if(count->tab > max1) {
        max1= count->tab;
        delimiter = ' ';
    }  if(count->comma > max1) {
        max1= count->comma;
        delimiter = ',';
    }  if(count->semicolon > max1) {
        max1= count->semicolon;
        delimiter = ';';
    }  if(count->pipe > max1) {
        max1= count->pipe;
        delimiter = '|';
    }  if(count->single_quote_fwd > max1) {
        max1= count->single_quote_fwd;
        delimiter = '\'';
    }  if(count->double_quote_fwd > max1) {
        max1= count->double_quote_fwd;
        delimiter = '\"';
    }  if(count->fwd_slash > max1) {
        max1= count->fwd_slash;
        delimiter = '/';
    }   if(count->bck_slash > max1) {
        max1= count->bck_slash;
        delimiter = '\\';
    }  if(count->open_bracket > max1) {
        max1= count->open_bracket;
        delimiter = '{';
    }  if(count->close_bracket > max1) {
        max1= count->close_bracket;
        delimiter = '}';
    }

    if(count->tab == max1) {
        max_count++;
    }  if(count->comma == max1) {
        max_count++;
    }  if(count->semicolon == max1) {
        max_count++;
    }  if(count->pipe == max1) {
        max_count++;
    }  if(count->single_quote_fwd == max1) {
        max_count++;
    }  if(count->double_quote_fwd == max1) {
        max_count++;
    }  if(count->fwd_slash == max1) {
        max_count++;
    }   if(count->bck_slash == max1) {
        max_count++;
    }  if(count->open_bracket == max1) {
        max_count++;
    }  if(count->close_bracket == max1) {
        max_count++;
    }
    
    if(max_count >=2)
    {
        printf("CONFUSING");
        return 0;
    }

    printf("Freq Size = %d : %d : %d", x, freq[0],freq[1]);
    if(isRepeating( freq,x)) {
        printf("CONFUSING");
        return 0;
    }

    fseek(fptr,0, SEEK_SET);
    printf("\n\nHelsse %d\n", count->tabspacecount);


    while((c= fgetc(fptr))!= EOF) {
        
        if(isDelimiter(c)){
            fputc(delimiter,outptr);
            printf("%c",delimiter);
            if(delimiter == ' ') {
                int i =1; 
                while (i < count->tabspacecount)
                {
                   fputc(' ',outptr);
                   printf(" ");
                   i++;
                }
            }
        } else {
            fputc(c, outptr);
            printf("%c",c);
        }
    }

    fclose(fptr);
    fclose(outptr);
    return 0;
}