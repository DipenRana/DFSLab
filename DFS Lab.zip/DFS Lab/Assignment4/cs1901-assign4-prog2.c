/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Prog2 Predictive Text (also known as T9) technology
  Acknowledgements:
  Note: The program is written according the sample inputs given in the assignment. I have not considered the number of
        contacts in the starting of input file.
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int num = 10;

int isSubstring(char *s1, char *s2)         //function to check if s1 is substring of s2.
{ 
    int M = strlen(s1); 
    int N = strlen(s2); 
  
    /* A loop to slide pat[] one by one */
    for (int i = 0; i <= N - M; i++) { 
        int j; 
  
        /* For current index i, check for pattern match */
        for (j = 0; j < M; j++) 
            if (s2[i + j] != s1[j]) 
                break; 
  
        if (j == M) 
            return i;
    } 
  
    return -1; 
} 


int main(int ac, char *av[]) {
    FILE *fptr;
    char ch[1000];     //static array to store the contact.
    int len = strlen(av[2]);
    char *str = av[2];
    char **result;

    fptr = fopen(av[1], "r");   // opening the input file containing contacts.

    int p =0;           //num of contacts in file.
    int res = 0;        //num of contacts in result.

    result = (char **)malloc(num * sizeof(char*));        //Dynamic results array to store resulting contacts.

    while(fgets (ch, 1000, fptr)!=NULL) {          // reading the file line by line.
        int x = strlen(ch);
        ch[x-1] = '\0';
        if(isSubstring( str, ch) != -1){               //Checking if the contact contains the given substring
            result[res] = malloc((1000) * sizeof(char));
            strcpy(result[res],ch);
            res++;
            if(res == num){
                num = num*2;
                result = realloc(result,num*sizeof(char*));
            }
           // printf("%s", ch);
        }
            
    }

    for(int i=0; i< res; i++) {         //sorting the results array
		for (int j=0; j<i; j++) {
	 		int x = strcasecmp(result[i],result[j]);
	 		if (x < 0) {
	 			char temp[1000];
	 			strcpy(temp, result[i]);
   				strcpy(result[i], result[j]);
   				strcpy(result[j], temp);
	 		}
	 	}
	}
    
    for(int i=0; i< res; i++) {         //printing the results.
        printf("%s\n",result[i]);
    }

    for(int i=0; i< res; i++) {         //printing the results.
        free(result[i]);
    }

    free(result);

    return 0;
}