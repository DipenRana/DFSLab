#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fptr, *fptr2;
    char c;
    fptr = fopen("1.txt","r");
     if (fptr == NULL)
    {
        printf("File is not available \n");
    }
    printf("printing input file \n");
    while((c = fgetc(fptr)) != EOF)
        printf("%c", c);

    fptr2 = fopen("2.txt", "w"); 
    if (fptr2 == NULL) 
    { 
        printf("Cannot open file  \n"); 
        exit(0); 
    } 
    
    fseek(fptr,0, SEEK_SET);
    // Read contents from file 
    c = fgetc(fptr); 
    while (c != EOF) 
    { 
        fputc(c, fptr2); 
        c = fgetc(fptr); 
    } 
  
    printf("\nContents copied to "); 
  
    fclose(fptr); 
    fclose(fptr2); 

    return 0;
}