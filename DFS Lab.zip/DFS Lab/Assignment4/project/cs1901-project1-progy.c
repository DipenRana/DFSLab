/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Project 1: Fillable array. (Amortized solution)
  Acknowledgements: Please read "Fillable arrays with constant time operations and a single bit of
                    redundancy" paper for description of the implementation.
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int naive = 0;      // Naive bit. (0 = False i.e. Linked List Mode, 1 = True i.e Naive Mode)

int n = 350;        // Total size of array. (constant for simplification.)
int cl = 50;        // CL. (as descibed in paper)
int elements = 0;   // largest index set by write (for printing).

int allocateNode(int *arr) {        //Function to allocate node(consecutive 3 indexes from N part of array(data structure))
    int L_len = n/cl;               //instead of double linked list using single linked list for simplification.
    int N_len = n- L_len - 2;
    
    int start = L_len + 2;
    //printf("\narr[1] =%d",arr[1]);

    int index = start + 3 * arr[1];
    arr[index -1] = index;      //setting next pointer of last node.(only consicutive allocation is done in this LL.)

    arr[1]++;       //incrementing numActive

    return index;
}

int LL_Read(int i, int *arr){
    int j = floor((i)/cl) + 2;

    if(arr[j] == n){        // n = NULL
        return arr[0];      // returning del_last
    } else {
        int ind = arr[j];   // L[j] entry i.e. head of the linked List.
        while(arr[ind+2] != -1) {       //traversing the linked list.
            if(arr[ind] == i){
                return arr[ind+1];
            }
            else
                ind = arr[ind+2];
        }
        if(arr[ind] == i){      //checking last ele in list.
            return arr[ind+1];
        }
        else
            return arr[0];      //del_last
    }
}

void Conversion_LLToNaive(int *arr) {       // Function to convert from LL mode to Naive mode. 
    int *x;                                 // (for simplification taken dynamic array, otherwise it has to be inplace conversion)
    x = malloc(elements*sizeof(int));
    for (int i = 0; i < elements; i++)
    {
        x[i] = LL_Read(i,arr);

    }
    for (int i = 0; i < elements; i++)
    {
        arr[i] = x[i];
    }

    free(x);
    naive = 1;      // setting naive mode
}

void LL_write(int i, int del, int *arr) {
    int j = floor((i)/cl) + 2;

    if(arr[j] != n) {       //n means null
        //traverse LL L[j]
        int ind = arr[j];
        while(arr[ind+2] != -1) {
            if(arr[ind] == i){      // LL contain node with index i.(i is active)
                arr[ind+1] == del;
                return;
            }
            else
                ind = arr[ind+2];
        }
        if(arr[ind] == i) {
            arr[ind+1] = del;
            return;
        }

        int x = allocateNode(arr);     // Append new node to end of LL.
    
        arr[x] = i;
        arr[x+1] = del;
        arr[x+2] = -1;
    } else {
        int  x = allocateNode(arr);     // allocate first node in the LL.
        arr[j] = x;

        arr[x] = i;
        arr[x+1] = del;
        arr[x+2] = -1;
    }   

    if(elements < i)
        elements = i;

    int N_len = n-2-(n/cl) ;    

    if(arr[1] ==  N_len/3)          // LL mode can acomodate these many indexes.(otherwise switch to Naive mode)
        Conversion_LLToNaive(arr);
}



void LL_fill(int del, int *arr) {
    naive = 0;
    int L_len = n/cl;
    arr[0] = del;       //del_last
    arr[1] = 0;         // numActive

    for (int i = 2; i < L_len+2; i++)       // Setting L part of the array.(data structure)
    {
        arr[i]= n;
    }
}

void LL_printArray(int *arr) {              //printing array upto maximum index written.
    for (int i = 0; i <= elements; i++)     
    {
        printf("%d ",LL_Read(i,arr));
    }
    printf("\n");
}

int Naive_Read(int i, int *arr){        // Naive mode read.
    return arr[i];
}

void Naive_Write(int i, int del, int *arr) {    // Naive mode write.
    if(elements < i)
        elements = i;
    
    arr[i] = del;
}

void Naive_Fill(int del, int *arr) {        // Naive mode fill.
    // initialize LL mode.
    arr[0] = del;
    arr[1] = 0;
    int L_len = n/cl; 

    for(int i = 2; i< L_len+2; i++) {
        arr[i] = n;
    }

    naive = 0;      // Switching to LL mode.
}

void Naive_printArray(int *arr) {       //printing array upto maximum index written.
    for (int i = 0; i <= elements; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}


//**********************************************  MAIN()  *******************************************************//

int main(int ac, char *av[]) {
    
    int L_len = n/cl;       // 7
    char ch[1000];      // To read lines of input file.

    int *arr;       // Array Data Structure.

    FILE *fptr;

    fptr = fopen(av[1], "r");

    fgets(ch, 1000, fptr);
    arr = malloc(n*sizeof(int));

    int k = strlen(ch), num=0;
   
    int x = 0;

    arr[0] = 0;     // Del.last         //Initializing LL mode
    arr[1] = 0;     // numActive

    for(int i = 2; i< L_len +2; i++) {      //Initializing LL mode
        arr[i] = n;
    }

    for (int i = 0; i < k; i++)         // writing the elements in array from 1st input line.
    {   
        if(ch[i] != ' ' && ch[i] != '\n'){
            num = num * 10 + ch[i] - 48;
        } else if(ch[i] == ' ' || ch[i] == '\n') {
            LL_write(x,num, arr);
            x++;
            num = 0;
        }
    }

    while(fgets(ch, 1000, fptr)!=NULL) {    // Switch cases for subsequent input lines.
        int len = 0;
        switch (ch[0]) {
        case '+':   //*********************************** write **************************//
            num = 0;
            int in[2];
            int i = 1, j =0;
            len = strlen(ch);
            if(ch[i] == ' ')
                i++;
                
            for ( ; i < len; i++)
            {    
                if(ch[i] != ' ' && ch[i] != '\n'){
                    num = num * 10 + ch[i] - 48;
                } else if(ch[i] == ' ' || ch[i] == '\n'){
                    in[j++] = num;
                    num = 0;
                }
            }
            if(ch[len-1] >= '0'&& ch[len-1] <= '9')
                in[1] = num;
            
            if(naive == 0) {
                LL_write(in[0],in[1],arr);
                LL_printArray(arr);
            }
            else {
                Naive_Write(in[0],in[1], arr);
                Naive_printArray(arr);
            }

            break;
        case '=':   //*********************************** read **************************//
            num = 0;
            i=1;
            if(ch[i] == ' ')
                i++;
            len = strlen(ch);
            for ( ; i < len; i++)
            {    
                if(ch[i] != ' ' && ch[i] != '\n' && i != len-1){
                    num = num * 10 + ch[i] - 48;
                } else if(ch[i] == ' ' || ch[i] == '\n' || i == len-1){
                    if(naive == 0)
                        printf("%d\n", LL_Read(num,arr));
                    else
                        printf("%d\n", Naive_Read(num,arr));
                    
                    break;
                }
            }

            break;
        case '@':   //*********************************** fill **************************//
            num = 0;
            i=1;
            len = strlen(ch);
            if(ch[i] == ' ')
                i++;
            for ( ; i < len; i++)
            {    
                if(ch[i] != ' ' && ch[i] != '\n' && i != len-1){
                    num = num * 10 + ch[i] - 48;
                } else if(ch[i] == ' ' || ch[i] == '\n' || i == len-1){
                    if(naive == 0){
                        LL_fill(num,arr);
                        LL_printArray(arr);
                    } else {
                        Naive_Fill(num,arr);
                        Naive_printArray(arr);
                    }
                    
                    break;
                }
            }
            
            break;
        default:
            printf("Incorrect operator detected.");
            break;
        }
    }

    return 0;
}