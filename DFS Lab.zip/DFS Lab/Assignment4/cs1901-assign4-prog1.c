/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Dec-19
  Program description: Prog1 File delimiter transformation.
  Acknowledgements:
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

typedef struct{                 //structure definition for counting frequencies of delimiters.          
    int tab, tabspacecount;
    int comma,semicolon, pipe, single_quote_fwd,
        double_quote_fwd, open_bracket, close_bracket,
        fwd_slash, bck_slash;
} DELIMITER_COUNT;

void checkDelimiter(DELIMITER_COUNT *cnt, char ch) {    //function to check delimiter and incrementing the count.
    if(ch == ' '){
        cnt->tab = cnt->tab +1;
    } else if(ch == ',') {
        cnt->comma = cnt->comma +1;
    } else if(ch == ';') {
        cnt->semicolon = cnt->semicolon +1;
    } else if(ch == '|') {
        cnt->pipe = cnt->pipe +1;
    } else if(ch == '\'') {
        cnt->single_quote_fwd = cnt->single_quote_fwd +1;
    } else if(ch == '\"') {
       cnt->double_quote_fwd = cnt->double_quote_fwd +1;
    } else if(ch == '/') {
        cnt->fwd_slash = cnt->fwd_slash +1;
    } else if(ch == '\\') {
        cnt->bck_slash = cnt->bck_slash +1;
    } else if(ch == '{') {
        cnt->open_bracket = cnt->open_bracket +1;
    } else if(ch == '}') {
        cnt->close_bracket = cnt->close_bracket +1;
    }
}

void initialize_Count(DELIMITER_COUNT *count) {     //initializing the delimiter count object.
    count->tab = 0;
    count->tabspacecount = 0;
    count->comma = 0;
    count->semicolon = 0;
    count->single_quote_fwd = 0;
    count->double_quote_fwd = 0;
    count->pipe = 0;
    count->open_bracket = 0;
    count->close_bracket = 0;
    count->fwd_slash = 0;
    count->bck_slash = 0;
}

int isDelimiter(char ch) {          //function to check if the char c is a delimiteror not.
    if(ch == ' ' ||ch == ',' ||ch == ';' ||ch == '\'' ||ch == '\"' ||ch == '/' ||ch == '\\' ||ch == '|' ||
        ch == '{' ||ch == '}' )
        return 1;
    else
        return 0;
    
}

int main(int ac, char *av[]) {
    FILE *fptr, *outptr;
    DELIMITER_COUNT *count;        // var to count the delimiter freq.
    int n;
    char c;
    int spaceCount[10], freq[10];   //variables to track diff size tabs.

    for (int i = 0; i < 10; i++)    //initializing the spacecount and freq.
    {
        spaceCount[i] = 0;
        freq[i] = 0;
    }

    count = (DELIMITER_COUNT *)malloc(sizeof(DELIMITER_COUNT)); 
    //printf("%s %s \n",av[1],av[2]);

    fptr =  fopen(av[1], "r");      //opening the input file.
    if (fptr == NULL)
        printf("File is not available \n");

    outptr = fopen(av[2], "w");     //opening the output file.
    if (outptr == NULL)
        printf("Cannot open file  \n"); 

    initialize_Count(count);        //initializing count var.


    int x = 0;
    while((c= fgetc(fptr)) != EOF) {        //reading the input file char by char.
        //printf("%c", c);
        checkDelimiter(count, c);           // checking and incrementing count if c is delimiter.
        if(c == ' '){           // if delimiter is space then counting the no. of spaces in tab and its freq.
            int j = 1,i;
            while ((c= fgetc(fptr)) != EOF && c == ' ')
                j++;

            for ( i = 0; i < x; i++)
            {
                if(spaceCount[i]== j) {
                    freq[i]++;
                    break;
                }
            }
            if(i == x) {
                spaceCount[i] = j;
                freq[i]++;
                x++;
            }
        }
    }

    char delimiter ;

    int max1 = -1;
    int max_count = 0;
    
    if(count->comma > max1) {           // computing the maximum frequency delimiter
        max1= count->comma;
        delimiter = ',';
    }  if(count->semicolon > max1) {
        max1= count->semicolon;
        delimiter = ';';
    }  if(count->pipe > max1) {
        max1= count->pipe;
        delimiter = '|';
    }  if(count->single_quote_fwd > max1) {
        max1= count->single_quote_fwd;
        delimiter = '\'';
    }  if(count->double_quote_fwd > max1) {
        max1= count->double_quote_fwd;
        delimiter = '\"';
    }  if(count->fwd_slash > max1) {
        max1= count->fwd_slash;
        delimiter = '/';
    }   if(count->bck_slash > max1) {
        max1= count->bck_slash;
        delimiter = '\\';
    }  if(count->open_bracket > max1) {
        max1= count->open_bracket;
        delimiter = '{';
    }  if(count->close_bracket > max1) {
        max1= count->close_bracket;
        delimiter = '}';
    }

    if(count->tab == max1) {        // checking if two maximum exist.
        max_count++;
    }  if(count->comma == max1) {
        max_count++;
    }  if(count->semicolon == max1) {
        max_count++;
    }  if(count->pipe == max1) {
        max_count++;
    }  if(count->single_quote_fwd == max1) {
        max_count++;
    }  if(count->double_quote_fwd == max1) {
        max_count++;
    }  if(count->fwd_slash == max1) {
        max_count++;
    }   if(count->bck_slash == max1) {
        max_count++;
    }  if(count->open_bracket == max1) {
        max_count++;
    }  if(count->close_bracket == max1) {
        max_count++;
    }
    
    if(max_count >=2)
    {
        printf("CONFUSING");
        return 0;
    }

    int flag = 0;
    for(int i =0; i<x; i++){        // checking if any tab has maximum frequency.
        if(freq[i]>max1) {
            max1 = freq[i];
            flag = 1;
            delimiter = ' ';
        }
    }

    if(flag) {              // checking if two tabs having same maximum freq.
        int temp = 0;
        for(int i =0; i<x; i++){
            if(freq[i] == max1) {
               temp++;
               count->tabspacecount = spaceCount[i];
            }
        }
        if(temp >= 2 ) {
            printf("CONFUSING");
            return 0;
        }
    }

    fseek(fptr,0, SEEK_SET);    //setting the read pointer to starting of the input file.


    while((c= fgetc(fptr))!= EOF) {         //reading the input file and copring the content to output file with appropriate delimiter.
        
        if(isDelimiter(c)){
            fputc(delimiter,outptr);
            if(delimiter == ' ') {
                int i =1; 
                while (i < count->tabspacecount)
                {
                   fputc(' ',outptr);
                   i++;
                }

                while ((c= fgetc(fptr)) != EOF && c == ' ');
                putc(c,outptr);
            }
        } else {
            fputc(c, outptr);
        }
    }

    free(count);
    fclose(fptr);       //closing the file pointers.
    fclose(outptr);
    return 0;
}