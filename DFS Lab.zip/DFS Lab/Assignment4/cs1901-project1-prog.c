/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Project 1: Fillable array.
  Acknowledgements:
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int naive = 0;

int n = 350;
int cl = 50;
int elements = 0;

int allocateNode(int *arr) {
    int L_len = n/cl;
    int N_len = n- L_len - 2;
    
    int start = L_len + 2;
    //printf("\narr[1] =%d",arr[1]);

    int index = start + 3 * arr[1];
    arr[index -1] = index;

    arr[1]++;

    return index;
}


void LL_write(int i, int del, int *arr) {
    int j = floor((i)/cl) + 2;

    if(arr[j] != n) {       //n means null
        //traverse LL L[j]
        int ind = arr[j];
        while(arr[ind+2] != -1) {
            if(arr[ind] == i){
                arr[ind+1] == del;
                return;
            }
            else
                ind = arr[ind+2];
        }
        if(arr[ind] == i) {
            arr[ind+1] = del;
            return;
        }

        int x = allocateNode(arr);
        elements++;
        //printf("\n =%d",x);
        arr[x] = i;
        arr[x+1] = del;
        arr[x+2] = -1;
    } else {
        int  x = allocateNode(arr);
        elements++;
        arr[j] = x;

        arr[x] = i;
        arr[x+1] = del;
        arr[x+2] = -1;
    }        
}

int LL_Read(int i, int *arr){
    int j = floor((i)/cl) + 2;

    if(arr[j] == n){
        return arr[0];
    } else {
        int ind = arr[j];
        while(arr[ind+2] != -1) {
            if(arr[ind] == i){
                return arr[ind+1];
            }
            else
                ind = arr[ind+2];
        }
        if(arr[ind] == i){
            return arr[ind+1];
        }
        else
            return arr[0];
    }
}

void LL_fill(int del, int *arr) {
    naive = 0;
    int L_len = n/cl;
    arr[0] = del;       //del_last
    arr[1] = 0;         // numActive

    for (int i = 2; i < L_len+2; i++)
    {
        arr[i]= n;
    }
}

void printArray(int *arr) {
    for (int i = 0; i < elements; i++)
    {
        printf("%d ",LL_Read(i,arr));
    }
    printf("\n");
}

int main(int ac, char *av[]) {
    
    int L_len = n/cl;       // 7
    char ch[1000];

    int *arr;

    FILE *fptr;

    fptr = fopen(av[1], "r");

    fgets(ch, 1000, fptr);
    arr = malloc(n*sizeof(int));

    int k = strlen(ch), num=0,mlt = 1;
   
    int x = 0;

    arr[0] = 0;     //Del.last
    arr[1] = 0;     // numActive

    for(int i = 2; i< L_len; i++) {
        arr[i] = n;
    }
    for (int i = 0; i < k; i++)
    {   
        
        if(ch[i] != ' ' && ch[i] != '\n'){
            num = num * 10 + ch[i] - 48;
        } else if(ch[i] == ' ' || ch[i] == '\n'){
            // arr[x] = num;
            // printf("== %d", arr[x]);
            LL_write(x,num, arr);
            x++;
            num = 0;
        }
    }

    while(fgets(ch, 1000, fptr)!=NULL) {
        int len = 0;
        switch (ch[0]) {
        case '+':   // write
            num = 0;
            int in[2];
            int i = 1, j =0;
            len = strlen(ch);
            if(ch[i] == ' ')
                i++;
                
            for ( ; i < len; i++)
            {    
                if(ch[i] != ' ' && ch[i] != '\n' && ch[i] != EOF){
                    num = num * 10 + ch[i] - 48;
                } else if(ch[i] == ' ' || ch[i] == '\n' || ch[i] == EOF){
                    in[j++] = num;
                    num = 0;
                }
            }
            if(ch[len-1] >= '0'&& ch[len-1] <= '9')
                in[1] = num;
           
            LL_write(in[0],in[1],arr);

            
            printArray(arr);
            break;
        case '=':   // read
            num = 0;
            i=1;
            if(ch[i] == ' ')
                i++;
            len = strlen(ch);
            for ( ; i < len; i++)
            {    
                if(ch[i] != ' ' && ch[i] != '\n' && ch[i] != EOF){
                    num = num * 10 + ch[i] - 48;
                } else if(ch[i] == ' ' || ch[i] == '\n' || ch[i] == EOF){
                    printf("Read(%d)=%d\n",num,LL_Read(num,arr));
                    break;
                }
            }

            break;
        case '@':   // fill
            num = 0;
            i=1;
            len = strlen(ch);
            if(ch[i] == ' ')
                i++;
            for ( ; i < len; i++)
            {    
                if(ch[i] != ' ' && ch[i] != '\n' && ch[i] != EOF){
                    num = num * 10 + ch[i] - 48;
                } else if(ch[i] == ' ' || ch[i] == '\n' || ch[i] == EOF){
                    LL_fill(num,arr);
                    break;
                }
            }

            printArray(arr);
            break;
        
        default:
            printf("Incorrect operator detected.");
            break;
        }
    }


    return 0;
}