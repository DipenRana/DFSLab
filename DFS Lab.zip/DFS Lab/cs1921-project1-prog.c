/*-----------------------------------
  Name: Anoop Kumar
  Roll number: CS1921
  Date: 15/12/2019
  Program description: Project 1
  Acknowledgements: For Futher development array can be reallocated
------------------------------------*/
#include<stdio.h>
#include<stdlib.h>

int Naive = 0,Cl=50;
int total=0;
//Folknore Data Structure
typedef struct
{
    int numActive;
    int Last;
    int *A,*B,*C;
}Folk;

//Fillable Function
Folk F_fill(Folk *Arr,int last)
{
    Arr->numActive = 0;
    Arr->Last = last;
    return *Arr;
}
//To write in array
Folk F_write(Folk *Arr,int num,int pos)
{
    Arr->A[pos] = num;
    total++;
    if((Arr->C[pos] > Arr->numActive)|| (Arr->B[Arr->C[pos]] != pos))
    {
        Arr->numActive++;
        Arr->B[Arr->numActive] = pos;
        Arr->C[pos]=Arr->numActive;
    }   
    return *Arr;
}
//for deletion
Folk F_delete(Folk *Arr,int pos)
{
    if(Arr->numActive!=0)
    {
        Arr->B[Arr->C[pos]]=Arr->B[Arr->numActive];
        Arr->C[Arr->B[Arr->numActive]]=Arr->C[pos];
    }
    return *Arr;
}
//reading from array
int F_read(Folk *Arr,int pos)
{
    if(Arr->C[pos]<=Arr->numActive)
    {
        if(Arr->B[Arr->C[pos]]==pos)
            return Arr->A[pos];
        else
        {
            return Arr->Last;
        }   
    }
    else
        return Arr->Last;
}
//initialisation
Folk F_ini(Folk *Arr,int n)
{
   Arr->numActive=0;
   Arr->Last=0;
   Arr->A = (int *)malloc((n/Cl) * sizeof(int));
   Arr->B = (int *)malloc((n/Cl) * sizeof(int));
   Arr->C = (int *)malloc((n/Cl) * sizeof(int));
    return *Arr;
}
//To Print Entire Available Array
void printArray(Folk *arr) {
    for (int i = 0; i < total; i++)
    {
        printf("%d ",F_read(arr,i));
    }
    printf("\n");
}
//Main Function
int main(int ac, char *av[])
{
   Folk *Arr;
   int n=350;
   Arr = (Folk*)malloc(n * sizeof(Folk));
   *Arr = F_ini(Arr,n);

   FILE *input;
   input = fopen(av[1], "r");

    //initial input
    int num,ps,x;
    char c;
    do
    {
        x = fscanf(input,"%d%c",&num,&c);
        //printf("%d%c",num,c);
        if(x>0)
        {
            *Arr= F_write(Arr,num,total);
        }
    }while(x>0&&c!='\n');
    
    x=fscanf(input,"%c",&c);
    while(x!=EOF)
    {
        if(c == '\n')
            x=fscanf(input,"%c ",&c);
        if(c == '+')
        {
            x=fscanf(input,"%d %d\n",&ps,&num);
            *Arr=F_write(Arr,num,ps);
            printArray(Arr);
        }
        else if( c == '=')
        {
            x=fscanf(input,"%d\n",&num);
            printf("%d\n",F_read(Arr,num));
        }
        else if (c == '@')
        {
            x=fscanf(input,"%d ",&num);
            *Arr=F_fill(Arr,num);
            printArray(Arr);
        }
        else
        {
            printf("Wrong Input\n");
        }
        x=fscanf(input,"%c",&c);
    }
    fclose(input);
    free(Arr);
   return 0;
}