#include <stdio.h>
#include <stdlib.h>

#define MAX(a,b) (((a)>(b))?(a):(b))

typedef struct node {
    int data;
    int left, right, parent, height; // following Weiss, DS & AA in C++, 4ed.
} AVL_NODE;

int z = 0;

int calcHeight(AVL_NODE *root, int n) {
    if(n == -1)
        return 0;

    if(root[n].left == -1 && root[n].right == -1)
        return 1;
    else if(root[n].left == -1)
        return 1 + calcHeight(root, root[n].right);
    else if(root[n].right == -1) {
        return 1 + calcHeight(root, root[n].left);
    } else {
        int lh = calcHeight(root, root[n].left);
        int rh = calcHeight(root, root[n].right);

        if(MAX(lh,rh)){
            return 1 +lh;
        } else
        {
            return 1 + rh;
        }
    }
}



int checkAVL(AVL_NODE *root, int n) {
    if(root == NULL)
        return 0;
    
    if( n == -1)
        return 1;

    int l_hight = calcHeight(root, root[n].left);
    int r_hight = calcHeight(root, root[n].right);

    int p,q;
    int diff = l_hight - r_hight;
    
    //printf("%d %d %d\n", l_hight, r_hight, diff);
    if(diff >= -1 && diff <= 1 ) {
      p = checkAVL(root, root[n].left);
      q = checkAVL(root, root[n].right);
      if(p && q)
        return 1;
    } else {
        return 0;
    }
    
}

void inorder(AVL_NODE* root, int n, int* arr) {
    if( n != -1){

    inorder(root, root[n].left , arr);
    arr[z] = root[n].data;
    printf("\n%d", arr[z]);
    z++;
    inorder(root, root[n].right, arr);
    }
}

int main(){

    AVL_NODE *root;
    int k,n;
    char  c;
    int num = 0;
    int *in;


        printf("Enter no of nodes in tree\n");
        num = 0;
        do{
          scanf("%c", &c );
          if(c == ' ' || c == '\n'){
            n = num;
          } else {
            num = num *10 + c - 48;
          }
        } while (c != '\n');

        root = (AVL_NODE *) malloc(n*sizeof(AVL_NODE));

        for(int i=0; i<n ; i++) {
          num =0;
          int spc = 0;
          do{
            scanf("%c", &c );
            if(c == ' '){
                spc++;
              if(spc == 1)
                root[i].data = num;
              else if(spc == 2)
                root[i].left = num;
              num =0;
            } else if(c == '\n') {
                if(num == -29)
                  num = -1;
                  root[i].right = num;
                  num = 0;
                  spc = 0;
            } else {
                if(c == '-'){
                    scanf("%c", &c);
                    if(c == '1')
                    num = -1;
                } else
                    num = num * 10 + c - 48;
            }
          } while(c != '\n');
        }

    printf("\n\n");
        for(int i =0; i<n; i++){
            if(root[i].left < n && root[i].right < n)
                printf("%d %d %d \n",root[i].data,root[i].left,root[i].right);
            else
            {
                printf("Invalid input enterd");
                return 0;
            }
            
        }

    in = (int *) malloc(n*sizeof(int));
    if(checkAVL(root, 0) ){
         inorder(root, 0, in);
        for(int i = 1; i< n ; i++){
            if(in[i-1] >= in[i]){
                printf("\n%d", in[i]);
                printf("\nNOT AVL");
                return 0;
            }
        }
        printf("Avl Tree");
    }
    else
    {
        printf("NOT");
    }
    

    return 0;
}