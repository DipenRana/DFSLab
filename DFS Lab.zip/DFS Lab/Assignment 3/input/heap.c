#include"common.h"

typedef struct{
  char* str;
  int val;
}NODE;
int heapsize;

int createStruct(NODE* nd,char** names,int* value,int size){

  for(int i=0;i<size;i++){
    nd[i].str = names[i];
    nd[i].val = value[i];
  }
  return 0;
}
void initilize(NODE* v){
  v->str = "";
  v->val = -1;
}
void swap(NODE* arr, int i, int largest){
  NODE v;
  v.str = arr[i].str;
  v.val = arr[i].val;

  arr[i].str=arr[largest].str;
  arr[i].val=arr[largest].val;

  arr[largest].str = v.str;
  arr[largest].val=v.val;
//  free(v);

}


void heapify(NODE* arr,int size, int i){
    int largest = i; // Initialize largest as root
    int l = 2 * i + 1; // left
    int r = 2 * i + 2; // right

    // If left child is larger than root
    if (l < heapsize && arr[l].val > arr[largest].val) largest = l;

    // If right child is larger than largest so far
    if (r < heapsize && arr[r].val > arr[largest].val) largest = r;

    // If largest is not root
    if (largest != i) {
        swap(arr,i, largest);
    heapify(arr, size, largest);
    }
}
int isEmptyi(){
  if(heapsize==0)return 1;
  else return 0;
}

void extractMax(NODE* nd,int size,NODE* ans){
  if(heapsize<=0)return ;
  if(heapsize==1){
    heapsize--;
    ans->str=nd[0].str;
    ans->val=nd[0].val;
    //free(go[0]);
    //free(go);
    return;
  }
  ans->str=nd[0].str;
  ans->val=nd[0].val;
  swap(nd,heapsize-1,0);
  heapsize--;
  //if(ans.val==1)free(go[heapsize-1]);
  heapify(nd,size,0);
}

int parent(int i) { return (i-1)/2; }

void buildHeap(NODE* arr, int size) {// Function to build a Max-Heap
  heapsize=size;
    int startIdx = (size/ 2) - 1;
    // Perform reverse level order traversal
    // from last non-leaf node and heapify  each node

    for (int i = startIdx; i >= 0; i--) {
        heapify(arr, size, i);
    }
}

void insertKey(NODE* arr, NODE* v){
  //printf("%s ",v->st);
  heapsize++;
  int i=heapsize-1;
  arr[i].str=v->str;
  arr[i].val=v->val;
  while(i!=0 && arr[parent(i)].val<arr[i].val){
    swap(arr,i,parent(i));
    i=parent(i);
  }
}
void printHeap(NODE* arr, int size)
{
    printf("Array representation of Heap is:\n");
    for (int i = 0; i < heapsize; ++i)
        printf("%s %d ",arr[i].str ,arr[i].val);
    printf("\n");
}