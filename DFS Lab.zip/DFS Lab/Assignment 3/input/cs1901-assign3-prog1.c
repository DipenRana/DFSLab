/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 28-Oct-19
  Program description: Prog1 Minimizing cost of the event.
  Acknowledgements:
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "trie.h"
#include "trie.c"
#include "heap.c"

int main(int ac, char *av[]) {

    char **names;       // different names in the input 
    int *freq;          // frequency of each unique name
    int num = 100;      // size of each name

    names = malloc(ac * sizeof(char*));
    freq = malloc(ac * sizeof(int));

    for (int i = 0; i < ac; i++)
    {
        names[i] = malloc(num * sizeof(char));
    }

    int size;
    init_trie();

    for (int i = 1; i < ac; i++)        // inserting names in the trie
    {
        insert_string(av[i]);
    }
    
    size = trie_dfs(names,freq);        // computing names and their frequencies using trie.
    
    NODE* node = (NODE *) malloc(size*sizeof(NODE));
    createStruct(node, names, freq, size);          // adding names in the max heap according to fequencies.
    buildHeap(node, size);                          // building heap
    NODE n1, n2;
    initilize(&n1);
    initilize(&n2);

    for(int i=0; i < ac-1;i++){
        if(i%2==0){
            extractMax(node,size,&n1);
            printf("%s ",n1.str);                   // printing the maximum frequency name first and then the 2nd max
            n1.val--;                               // and again adding these names in the heap by decrementing the freq.

            if(n2.val!=0 && n2.val!=-1)
                insertKey(node,&n2);
            if(isEmptyi()){
                while(n1.val!=0){
                    printf("%s ",n1.str);
                    n1.val--;
                }
                return 0;
            }
            initilize(&n2);
        }
        else if(i%2==1 ){
            extractMax(node,size,&n2);
            printf("%s ",n2.str);
            n2.val--;

            if( n1.val!=0 && n1.val!=-1)
                insertKey(node,&n1);
            if(isEmptyi()){
                while(n2.val!=0){
                printf("%s ",n2.str);
                n2.val--;
                }
                return 0;
            }
            initilize(&n1);
        }
    }

    return 0;
}