/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 28-Oct-19
  Program description: Prog2 Vector Multiplication problem.
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int partition(int *arr,int a, int size) {             //partition function for QuickSort
  int i = a-1, j = size-1, v = arr[size-1], x;

  while(1) {
    do i = i+1; while(arr[i] < v);
    do j = j-1; while(arr[j] > v);
    if(i >= j) break;
    x = arr[i]; arr[i] = arr[j]; arr[j] = x;
  }
  x = arr[i]; arr[i] = arr[size-1]; arr[size-1] = x;
  return i;
}

void QuickSort(int* arr, int i, int size) {           //QuickSort Algorithm
  if( i < size){
    int pvt=  partition(arr,i, size);
    QuickSort(arr,i, pvt-1);
    QuickSort(arr, pvt + 1,size);
  }
}

int binarySearch(int *arr, int l, int r, int x) {      // Binary search for searching the divisors in the given set.
    while (l <= r) {
        int m = l + (r - l) / 2;
        if (arr[m] == x)return m;     
        if (arr[m] < x)l = m + 1;     
        else   r = m - 1;             
    }

    return -1;
}

int divisor(int *arr, int size, int x) {            //Function to find the divisors of an integer
    for(int i = size -1; i>= 0; i--) {
        if(x%arr[i] == 0) 
        return i;
    }
    return -1;
}

int isPrime(int n){             // Function to check if the number n is prime or not.
    int flag = 1;

    for (int i = 2; i <= sqrt(n) ; i++) { 
        // If n is divisible by any number between 
        // 2 and n/2, it is not prime 
        if (n % i == 0) { 
            flag = 0; 
            break; 
        } 
    } 

    return flag;
}

int main() {
    int n;
    char c;

    printf("Enter value of n\n");
    scanf("%d", &n);

    printf("Enter z vector\n");

    int *z_arr = (int *)malloc(n*sizeof(int));
    for(int i = 0; i < n; i++) {
        scanf("%d%c", &z_arr[i], &c);
    }

    printf("Enter values of set S\n");
    int *set = (int *)malloc(sizeof(int));
    int ind = 0;
    c = 'a';
    int num;
    do {
        scanf("%d%c", &num, &c);
        if( isPrime(num) ) {                // not saving the non prime integers in the set.
            set = (int *) realloc(set, (ind + 1)*sizeof(int));
            set[ind] = num;
            ind++;
        }
    } while( c != '\n');

    QuickSort(set, 0, ind);         // sorting the set.

    // for(int i = 0; i< ind; i++)
    //  printf("%d ",set[i]);

    int *tag = (int *) calloc(ind, sizeof(int));        // tag bits to keep tracks of use of integers in the set.

    int j,k, l;
    for(int i =0; i< n; i++) {         // Getting the 2 divisor of the vector z coeficients and checking them against set elements.
        j = divisor(set, ind, z_arr[i]);
        if(j == -1){
            printf("FALSE");
            return 0;
        }
        if(tag[j] == 1){
            printf("FALSE");
            return 0;
        }

        k = z_arr[i] / set[j];
        tag[j] = 1;
        l = binarySearch(set, 0, ind, k);
        if(l == -1){
            printf("FALSE");
            return 0;
        }
        if(tag[l] == 1){
            printf("FALSE");
            return 0;
        }
        tag[l] = 1;

    }
    printf("TRUE");
    free(tag);      //Freeing up the space.
    free(z_arr);
    free(set);
    return 0;
}