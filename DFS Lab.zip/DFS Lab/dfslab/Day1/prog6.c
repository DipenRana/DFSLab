#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>

#define MAX 10000

char * multiply(char[],char[]);

int main() {

	char a[MAX];
	char b[MAX];
	char *c;
	int la,lb;
	int i;

	FILE *fptr;

	if((fptr = fopen("multiply.txt","r")) == NULL) {
		printf("Error! in opening FILE\n");
		return -1;
	}

	fgets ( a, sizeof a, fptr );
	fgets ( b, sizeof b, fptr );
	printf("A= %s\n", a);
	printf("B=%s\n", b);
	printf("Multiplication of two numbers : ");
	c = multiply(a,b);
	printf("%s",c);

	getchar();
	getchar();

	return 0;
}

char * multiply(char a[],char b[]) {

	static char mul[MAX];
	char c[MAX];
	char temp[MAX];
	int la,lb;
	int i,j,k=0,x=0,y;

	long int carry=0;
	long sum = 0;

	la=strlen(a)-2;

	lb=strlen(b)-2;

	for(i=0;i<=la;i++){
		a[i] = a[i] - 48;
	}

	for(i=0;i<=lb;i++){
		b[i] = b[i] - 48;
	}

	for(i=lb;i>=0;i--){
		carry=0;

		for(j=la;j>=0;j--){
			temp[k++] = (b[i]*a[j] + carry)%10;
			carry = (b[i]*a[j]+carry)/10;
		}

		temp[k++] = carry;
		x++;

		for(y = 0;y<x;y++){
			temp[k++] = 0;
		}
	}

	k=0;
	carry=0;

	for(i=0;i<la+lb+2;i++){

		sum =0;
		y=0;

		for(j=1;j<=lb+1;j++){

			if(i <= la+j){
			sum = sum + temp[y+i];
			}

			y += j + la + 1;
		}

		c[k++] = (sum+carry) %10;
		carry = (sum+carry)/10;
	}

	c[k] = carry;
	j=0;

	for(i=k-1;i>=0;i--){
		mul[j++]=c[i] + 48;
	}

	mul[j]='\0';
	return mul;
}