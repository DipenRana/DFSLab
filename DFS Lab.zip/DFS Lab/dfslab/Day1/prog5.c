#include<stdio.h>

int main() {
	char ch[100][1000];
	FILE *fptr;
	int i=0, lines =0;

	if((fptr = fopen("sample.txt","r")) == NULL) {
		printf("Error! in opening FILE\n");
		return -1;
	}

	while ( fgets ( ch[i], sizeof ch[i], fptr ) != NULL ) {
		
		i++;
		lines++;
	}

	for(int i=0; i< lines; i++) {
		for (int j=0; j<i; j++) {
	 		int x = strcmp(ch[i],ch[j]);
	 		printf("x =%d\n",x);
	 		if (x < 0) {
	 			char temp[1000];
	 			strcpy(temp, ch[i]);
   				strcpy(ch[i], ch[j]);
   				strcpy(ch[j], temp);
	 		}
	 	}
	}
	printf("lines = %d\n", lines);

	 for(int i=0; i<lines; i++) {
	 	printf("%s",ch[i] );
	 }

	 fclose(fptr);
    

	getchar();
	getchar();
	return 0;

}