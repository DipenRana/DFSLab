#include<stdio.h>

int main() {
	char arr[20];
	int dist=0, count =0,x = 0;

	printf("Enter a String\n");
	scanf("%s",arr);
	printf("strlen = %d\n", strlen(arr));
	for(int i=0; i < strlen(arr); i++) {
		

		if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u' || 
			arr[i] == 'A' || arr[i] == 'E' || arr[i] == 'I' || arr[i] == 'O' || arr[i] == 'U' ) {

			count++;
			if(count > 2 && x!=dist) {
				printf("dist= %d\n", dist);
				printf("count= %d\n", count);
				printf("Your String is not NICE \n");
				getchar();
				getchar();
				return 0;
			}
			x = 0;
		} else {
			if(count ==1){
				dist++;
			}
			x++;
		}
	}
	printf("Your String is NICE\n");
	getchar();
	getchar();
	return 0;
}