#include<stdio.h>

int determinant(int A[15][15], int n) {
	int minor[15][15],
		i,j,k,c1,c2,
		det = 0,
		sign = 1;

	if(n==2){
		det = A[0][0] * A[1][1] - A[0][1]*A[1][0];
		return det;
	} else {
		for(i=0 ; i<n; i++) {
			c1 = 0;
			c2 = 0;
			for(j=0; j<n; j++) {
				for(k=0; k<n; k++) {
					if(j!=0 && k!= i) {
						minor[c1][c2] = A[j][k];
						c2++;
						if(c2> n-2) {
							c1++;
							c2=0;
						}
					}
				}
			}
			det +=sign*(A[0][i]*determinant(minor,n-1));
			sign=-1*sign;
		}
	}
	return det;
}

int main() {
	int mat[15][15], p, q, det;
	printf("Enter no. of rows:\n");
	scanf("%d",&p);
	printf("Enter no. of columns:\n");
	scanf("%d",&q);
	printf("Enter your matrics in row major order:\n");

	for(int i=0; i<p ; i++) {
		for(int j=0; j<q; j++) {
			scanf("%d",&mat[i][j]);
		}
	}

	printf("You Entered the following matrics\n");
	for(int i=0; i<p ; i++) {
		for(int j=0; j<q; j++) {
			printf("    %d",mat[i][j]);
		}
		printf("\n");
	}

	if(p!=q) {
		printf("Your matrics is NOT SQUARE matrics\n" );
	} else {
		det = determinant(mat,p);
		printf("determinant = %d\n",det);
		if(det==0){
			printf("You entered a SQUARE SINGULAR MATRICS\n");
		} else if(det==1) {
			printf("You entered a SQUARE UNIMODULAR MATRICS\n");
		} else {
			printf("SQUARE  OTHER\n");
		}
	}
	getchar();
	getchar();
	return 0;
}