#include<stdio.h>
#include<math.h>

struct Complex
{
	float real;
	float img;
};

Complex divide(Complex x,Complex y){
    Complex z;
    z.real = (x.real*y.real + x.img*y.img)/(y.real*y.real+y.img*y.img);
    z.img = (x.img*y.real - x.real*y.img)/(y.real*y.real + y.img*y.img);
    return z;
}

int main(){
	float a,b,c,r1,r2,x;
	Complex c1,c2, div;
	printf("Enter three real numbers\n");
	scanf("%f",&a);
	scanf("%f",&b);
	scanf("%f",&c);
	x = b*b - 4 * a * c;
	printf("X = %f\n",x);
	if (x < 0){
		c1.real = -1 * b / (2 * a);
		c1.img = sqrt(-1 * x)/(2 * a);
		c2.real = c1.real;
		c2.img = -1 * c1.img;
		printf("Two imaginary roots are : %f + %fi and %f %f i \n", c1.real,c1.img,c2.real,c2.img);
		div = divide(c1,c2);
		printf("Division of two imaginary roots = %f + %f i\n", div.real, div.img);
	} else {
		r1 = (-1 * b + sqrt(x)) / (2 *a);
		r2 = (-1 * b - sqrt(x)) / (2 *a);
		printf("Two real roots are: %f , %f \n", r1, r2 );
		if( r2 == 0 || r1 == 0) {
			printf("One of the root is zero\n");
			getchar();
		}
		printf("Ratio of roots = %f\n", r1/r2 );
	}

	getchar();
	getchar();

	return 0;
}