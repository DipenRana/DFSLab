#include<stdio.h>
int count =0;

int visitNode(int n,int k) {
    if(k==0)
      return 1;
    else if(n=1){
      return 2*k+1;
    }
}

int main() {
  int n,k,sum;
  printf("Enter the values for n and k\n" );
  scanf("%d",&n );
  scanf("%d",&k );

  sum = 0;
  for(int i=1; i<=k; i++){
    sum += visitNode(n-1,k-i);
  }
  sum = visitNode(n-1,k)+ 2*sum;
  printf("Cells reachable: %d\n",sum );
}
