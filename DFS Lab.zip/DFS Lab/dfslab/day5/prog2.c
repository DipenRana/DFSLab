#include <stdio.h>

int binomialCo(int n, int r) {

  if(n==r || r==0) {
    return 1;
  }
  return binomialCo(n-1,r-1) + binomialCo(n-1,r);

}

int main() {
  int n,r, ans;

  printf("Enter values of n and r in nCr form\n" );
  scanf("%d", &n );
  scanf("%d", &r );

  ans = binomialCo(n,r);
  printf("Binomial coeficient = %d\n",ans );
  return 0;
}
