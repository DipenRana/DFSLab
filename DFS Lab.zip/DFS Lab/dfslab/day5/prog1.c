#include<stdio.h>

void towerOfHanoi(char src, char dest, char spr, int n) {
  if( n==0 ) {
    return ;
  } else {
    towerOfHanoi(src, spr, dest, n-1);
    printf("Move disk from %c to %c\n", src, dest );
    towerOfHanoi(spr,dest, src, n-1);
  }
}
int main() {
  int n;
  char a= 'A', b= 'B', c= 'C';
  printf("Enter number of disks\n" );
  scanf("%d", &n );

  towerOfHanoi(a,c,b,n);

  printf("Congrats!!\n" );

  return 0;
}
