#include "stdio.h"

int f ( int n ){int s = 0;while (n--) s += 1 + f(n);return s;}
int main() {
    int n;

    printf("Enter the value of n\n" );
    scanf("%d", &n );

    printf(" F(n) = %d\n", f(n) );

    return 0;
}
