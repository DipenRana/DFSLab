#include<stdio.h>
#include <math.h>

int count = 0;
struct Cord {
  int x;
  int y;
};

void calcFavouringCases(int x, int y,int i, int j, int k) {
  struct Cord a[8];

  a[0].x= i+1;
  a[0].y= j+2;

  a[1].x= i+2;
  a[1].y= j+1;

  a[2].x= i+2;
  a[2].y= j-1;

  a[3].x= i-1;
  a[3].y= j-2;

  a[4].x= i+1;
  a[4].y= j-2;

  a[5].x= i-2;
  a[5].y= j-1;

  a[6].x= i-2;
  a[6].y= j+2;

  a[7].x= i-1;
  a[7].y= j+2;

  for(int z=0; z < 8; z++){
    if(a[z].x >= 0 && a[z].x < x && a[z].y >=0 && a[z].y < y  ){
      if( k==0){
        count++;
        return;
      }
      calcFavouringCases(x,y,a[z].x,a[z].y,k-1);
    }
  }

}

int main() {
  int x,y,i,j,k;
  int favor =0;
  float total =0.00f;
  float prob;
  printf("Enter values of x,y,i,j,k\n" );
  scanf("%d", &x );
  scanf("%d", &y );
  scanf("%d", &i );
  scanf("%d", &j );
  scanf("%d", &k );

  calcFavouringCases(x,y,i,j,k);

  printf("Count = %d\n", count );
  total = pow(8,k);
  printf("total = %f\n",total );

  prob = count / total;


  printf("Probability = %f\n", prob );

  return 0;
}
