#include<stdio.h>

int recursive_G(int n) {
  if(n==0 || n==1 || n==2) {
    return n;
  } else {
    return recursive_G(n-1) + recursive_G(n-2) + recursive_G(n-3);
  }
}

int iterative_G(int n) {
  int ans=0;
  int a=0,b=1,c=2;
  for(int i=3; i<=n; i++) {
      ans = a + b + c;
      a=b;
      b=c;
      c=ans;
  }

  return ans;
}

int main() {
  int n;

  printf("Enter value of n\n" );
  scanf("%d", &n );

  printf("%d\n", recursive_G(n) );
  printf("%d\n", iterative_G(n) );

  return 0;
}
