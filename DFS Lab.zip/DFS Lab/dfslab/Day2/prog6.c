#include<stdio.h>

int main(){
	unsigned int n,m;
	int k;

	printf("Enter the unsigned number n:\n");
	scanf("%u",&n);

	if (n & 1) {
		m=1;
	} else 
		m=0;

	printf("N is odd: %u\n",m );

	if (n & 3) {
		m=0;
	} else
		m=1;
	printf("N is divisible by 4: %u\n", m);

	m= n<<1;
	printf("N left shift by 1: %u\n",m );

	printf("Enter value of K:\n");
	scanf("%d",&k);
	m = (n << k) | (n >> (32 - k));
	printf("left rotate n by k bits = %u\n", m);

	m = (n >> k) | (n << (32 - k));
	printf("right rotate n by k bits = %u\n", m);

	getchar();
	getchar();

	return 0;
}