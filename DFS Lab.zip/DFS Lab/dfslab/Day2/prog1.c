#include<stdio.h>
#include<string.h>

void splitInput(int arr[], int sizeArr, char num[])
{
    for(int i = 0; i < sizeArr; i++)
        arr[i] = (int)num[i] - 48;
}

int main(){
  char ub[21],lb[21];
  char arub[21],arlb[21];
  int len1 =0, len2 =0,i=0,j=0,lbnum=0,ubnum=0,x,y;

  printf("Enter upper bound:\n" );
  scanf("%s", lb);
  printf("Enter upper bound\n" );
  scanf("%s", ub);

   i = 0;
   j = 0;

  while (i<strlen(ub)) {
    arub[j]=ub[i]- 48;
    i++;
    i++;
    printf("%d\n",arub[j] );
    j++;
  }
  len2 = j;
  i = 0;
  j = 0;

 while (i < strlen(lb) ) {
   arlb[j]=lb[i]- 48;
   i++;
   i++;
   printf("%d\n",arlb[j] );
   j++;
 }
 len1 = j;

for (i=0; i< len1;i++){
  lbnum  = lbnum*10 + arlb[i];
}

printf("%d\n", lbnum );

for (i=0; i< len2;i++){
  ubnum  = ubnum*10 + arub[i];
}
printf("%d\n", ubnum );

x = ubnum - lbnum;


for (int i=0; i<x ; i++) {
  lbnum++;
  y=lbnum;
  int k = 0;
  while(y != 0)
    {
        arub[k] = (y % 10) ;
        y = y / 10;
        k++;
    }

  for(int p= k-1; p>=0;p--) {
    if(p == 0)  
      printf("%c",arub[p]+48 );
    else
      printf("%c.",arub[p]+48 );
  }
  printf("\n" );
}


return 0;
}
