#include<stdio.h>
#include<math.h>

int main() {
  int m,n,X;
  float x,y,M,sqr;

  printf("Enter int m and n:\n" );
  scanf("%d",&m );
  scanf("%d",&n );
  printf("Enter float x and y:\n" );
  scanf("%f",&x );
  scanf("%f",&y );

  M= (float)m;
  X= (int)x;
  sqr = sqrt(m);

  if ((x+y) == (float)((int)(x+y)) || (M>x && M <y) || m ==X || (x >= 3.00 && x-3.00 < 0.3) || (m%2 == n%2) ||  sqr - floor(sqr) == 0.00)
    printf("TRUE\n" );
  else
    printf("FALSE\n" );

  return 0;
}
