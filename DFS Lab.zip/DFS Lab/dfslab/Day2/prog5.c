#include<stdio.h>
#include<math.h>

int main() {
  int no,sqr,len=0,x,y,num =1,p,q;
  printf("Enter a Number:\n" );
  scanf("%d",&no );
  sqr = no *no;
  printf("Square:%d\n", sqr );
  x=sqr;
  while(x){
    len++;
    x/=10;
  }
  for(int i=0;i < ceil((float)len/2); i++)
    num*=10;

  printf("num=%d\n",num );
  p=sqr%num;
  q=sqr/num;

  if(p+q == no)
    printf("Your number is KAPREKAR\n" );
  else
    printf("NOT Kaprekar\n" );

  return 0;
}
