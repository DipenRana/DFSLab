#include<stdio.h>

int main(){
  int n,sum = 0,mul = 1,x;

  //printf("Enter the Number:\n" );
  //scanf("%d",&n );

  for(int i = 1; i <1000; i++) {
    sum =0; mul = 1;
  x = i;
  while(x!=0) {
    sum += x%10;
    mul *= x%10;
    x = x/10;
  }

  if(i == sum + mul) {
    printf("You Entered a Special: %d\n",i );
  }
}
//  else{
//    printf("Not a special No.\n" );
//  }
  return 0;
}
