#include<stdio.h>

int main(){
int n;
printf("Enter no of rows:\n" );
scanf("%d",&n );

for(int i=0;i < n;i++) {
  for(int j=0;j<= 2*(n-1)-i;j++) {
    if(j-i== 0 || j == 2*(n-1)-i )
      printf("*");
    else
      printf(" " );
  }
  printf("\n" );
}

return 1;
}
