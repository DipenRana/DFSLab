#include<stdio.h>

int main() {
	int n,count =0;

	printf("Enter the number n: \n");
	scanf("%d", &n);

	for (int i=5 ; n/i >=1 ; i*=5 ) {
		count += n/i;
	}

	printf("No. of trailing zeros in N! = %d\n", count );

	getchar();
	getchar();
	return 0;
}