#include<stdio.h>

int main(){
  unsigned char i = 0;
  for(;i<=0;i++);
  printf("malay""bhata" );
  return 0;
}
