#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode
{
	int data;
	int leftChild, rightChild;
	int parent;
}TreeNode;

void inorder(int *arr, int i, int size){
	if(i>=size)
		return;
	inorder(arr, 2*i+1, size);
	printf("%d  ", arr[i] );
	inorder(arr, 2*i+2, size);
}

int main() {
	int *arr,n,i;

	printf("Enter number of nodes in tree.\n");
	scanf("%d", &n);
	arr = (int *) malloc(n*sizeof(int));

	printf("Enter the root.\n");
	for(i = 0; i<n; i++) {
		if(i != 0 && i%2 ==1){
			printf("Enter LC of index %d\n", (i-1)/2 );
		} else if(i != 0 && i%2 ==0){
			printf("Enter RC of index %d\n", (i-1)/2 );
		}
		scanf("%d",&arr[i]);
	}

	printf("\n\n Printing the resulting tree.\n\n");

//printing the tree using nodes
	int j =1,ar=0;
  for(int i =0; i < n; i++) {
    printf("   %d  ", arr[i]);
    if(i==ar){
      printf("\n" );
      j = j*2;
      ar = ar+j;
    }
  }

  printf("\n\nprinting inorder traversal:\n\n");

  inorder(arr, 0, n);

  free(arr);
	return 0;
}