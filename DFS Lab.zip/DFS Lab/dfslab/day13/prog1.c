/*
	Tree implementation using alternative approach.
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode
{
	int data;
	int leftChild, rightChild;
	int parent;
}TreeNode;

void printTree(TreeNode *root) {

	printf("Root: %d",root->data);
	printf("LC: %d    RC:%d",root->leftChild,root->rightChild);

}

int main(int argc, char const *argv[])
{
	int *arr,n,i;
	TreeNode *tree;

	printf("Enter number of nodes in tree.\n");
	scanf("%d", &n);
	arr = (int *) malloc(n*sizeof(int));

	printf("Enter the array\n");
	for(i = 0; i<n; i++) {
		scanf("%d",&arr[i]);
	}

	for(i = 0; i<n; i++) {
		printf("%d  ",arr[i]);
	}


	tree = (TreeNode *) malloc(n*sizeof(TreeNode));
	if(arr[0 != -1])  {
		printf("You Entered wronge sequence. Not able to build the tree\n");
		return 0;
	}

	for( i = 0; i<n ; i++) {		//inserting nodes in the tree
		tree[i].data = i;
		tree[i].leftChild = -1;
		tree[i].rightChild = -1;
		tree[i].parent = arr[i];
		if(arr[i] != -1) {
			if(tree[arr[i]].leftChild == -1) {
				tree[arr[i]].leftChild = i;
			} else if(tree[arr[i]].rightChild == -1) {
				tree[arr[i]].rightChild = i;
			} else {
				printf("You Entered wronge sequence. Not able to build the tree\n");
				return 0;
			}
		} 

	}

	printf("\n\n Printing the resulting tree.\n\n");

//printing the tree using nodes
/*int j =1,ar=1;

  for(int i =1; i <= size; i++) {
    printf("   %f  ",arr[i] );
    if(i==ar){
      printf("\n" );
      j = j*2;
      ar = ar+j;
    }
  }
*/

  int j =1,ar=0;
	for( i = 0; i < n; i++) {			//printing the tree using childs
		TreeNode *root = &tree[i];
		if(i==0)
		printf("Root: %d\n",root->data);

		printf("    %d    %d    ",root->leftChild,root->rightChild);
		if(i==ar){
      		printf("\n" );
      		j = j*2;
      		ar = ar+j;
    	}

	}

	free(arr);
	free(tree);
	return 0;
}