#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode
{
	int data;
	TreeNode *left, *right, *parent;
}TreeNodes;


TreeNode* buildTree(int *pre, int *post, int n) {
	TreeNode *node = (TreeNode *) malloc(sizeof(TreeNode));
	int i = 0,count =1;
	node->data = pre[0];
	node->left = NULL;
	node->right = NULL;

	int lc = pre[1];
	if(n==1)
		return node;
	while(post[i] != lc) {
		count++;
	}

	int *left_pre = (int *) malloc(count*sizeof(int));
	int *left_post = (int *) malloc(count*sizeof(int));
	int *right_pre = (int *) malloc((n-1-count)*sizeof(int));
	int *right_post = (int *) malloc((n-1-count)*sizeof(int));

	int k=0;
	for(int i=1; i<n; i++) {
		if(i<=count) {
			left_pre[k] = pre[i];
			left_post[k] = post[i-1];
		} else {
			right_pre[k] = pre[i];
			right_post[k] = post[i-1];
		}
	}

	node->left = buildTree(left_pre,left_post,count);
	node->right = buildTree(right_pre,right_post,n-1-count);

	return node;

}


void printTree(TreeNode *root) {
	if(root == NULL)
		return;
	printf("Root: %d",root->data);
	printf("LC: %d    RC:%d",root->left,root->right);

	printTree(root->left);
	printTree(root->right);

}

int main() {
	int *pre, *post, n;
	TreeNode *root;

	printf("Enter num of nodes.\n");
	scanf("%d",&n);

	printf("Enter the preorder of tree.\n");
	pre = (int *) malloc(n*sizeof(int));

	for(int i = 0; i < n; i++){
		scanf("%d", &pre[i]);
	}

	printf("Enter the Postorder of tree.\n");
	post = (int *) malloc(n*sizeof(int));

	for(int i = 0; i < n; i++){
		scanf("%d", &post[i]);
	}

	root = buildTree(pre,post,n);

	printTree(root);


	return 0;
}