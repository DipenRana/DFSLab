#include <stdio.h>
#include <stdlib.h>

int main() {

	int *arr;
	int n,i,x,flag =1 ;

	printf("Enter number of nodes in tree.\n");
	scanf("%d", &n);
	x = n+1;
	while(x!=0){
		if(x%2 == 0 || x ==1)
			x = x/2;
		else
		{	printf("No of nodes will not form tournament.\n");
			return 0;
		}
	}

	arr = (int *) malloc(n*sizeof(int));

	printf("Enter the root.\n");
	for(i = 0 ; i<n; i++) {

		if(i != 0 && i%2 ==1){
			printf("Enter LC of index %d\n", (i-1)/2 );
		} else if(i != 0 && i%2 ==0){
			printf("Enter RC of index %d\n", (i-1)/2 );
		}
		
		scanf("%d",&arr[i]);

	}


	printf("\n\n Printing the resulting tree.\n\n");

//printing the tree using nodes
	int j =1,ar=0;
  for(int i =0; i < n; i++) {
    printf("   %d  ", arr[i]);
    if(i==ar){
      printf("\n" );
      j = j*2;
      ar = ar+j;
    }

    if(i != 0 && i%2 ==0){
			if(arr[(i-1)/2] != arr[i] && arr[(i-1)/2] != arr[i-1]) {
				flag = 0;
			}
		}
  }


	if(flag){
		printf("The tree is a tournament tree\n");
	} else {
		printf("Your tree is NOT Tournament\n");
	}

	return 0;
}