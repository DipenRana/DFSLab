#include<stdio.h>

int main() {
  int arr[15], a;
  int brr[10], b, k, p=0,x;

  printf("Enter the size of array 1:\n" );
  scanf("%d", &a);
  printf("Enter the size of array 2:\n" );
  scanf("%d", &b);

  printf("Enter sorted array 1:\n" );

  for(int i =0 ; i< a; i++) {
    scanf("%d", &arr[i]);
  }

  printf("Enter sorted array 2:\n" );

  for(int i =0 ; i< b; i++) {
    scanf("%d", &brr[i]);
  }

  printf("Enter K:\n" );
  scanf("%d", &k );

  for(int i =0, j=0; i+j < a+b-1;)
  {
    if(arr[i]<=brr[j])
    {
      x= arr[i];
      i++; p++;
    }
    else {
      x= brr[j];
       j++; p++;
    }

    if(p==k)
    {
      printf("Kth smallest element :%d\n", x );
      break;
    }
  }

  return 0;

}
