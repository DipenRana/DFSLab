#include<stdio.h>
#include<stdlib.h>

int main() {
  int a,b,x,y, count = 0, blen = 0, alen = 0;
  int *aptr, *bptr;



  printf("Enter Two integers: \n" );
  scanf("%d", &a );
  scanf("%d", &b );

  x = a;
  y = b;

  while(x != 0)
  {
    x /= 10;
    ++alen;
  }

  while(y != 0)
  {
    y /= 10;
    ++blen;
  }

  printf("A length: %d\n", alen );
  printf("B length: %d\n", blen );
  aptr = (int *)malloc(alen * sizeof(int));
  bptr = (int *)malloc(blen * sizeof(int));

  x=a;
  y=b;


  if(a<b)
    printf("Not posible to have any occurance of B in A\n" );
  else {

    for (int i = 0; i < alen; i++) {
      *(aptr + i) = x%10;
      printf("%d ", *(aptr + i));
      x/=10;
    }

    for (int j = 0; j < blen; j++) {
      *(bptr + j) = y%10;
      printf("%d ", *(bptr + j));
      y/=10;
    }

    for(int i = 0; i < alen - blen +1; i++) {
      if(*(aptr + i) == *(bptr)) {
        int check = 1;
        for(int j=1; j< blen ; j++ ) {
          if (*(aptr + i +j) == *(bptr + j))
            check++;
        }

        if(check == blen)
          count++;
      }
    }

    printf("No of occurance of B in A: %d\n", count );


  }

  free(aptr);
  free(bptr);

  return 0;
}
