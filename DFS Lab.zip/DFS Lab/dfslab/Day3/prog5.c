#include<stdio.h>

struct Complex {
  int real;
  int img;
};

int main() {
  struct Complex a1,a2,ab,cd;
  int x;

  printf("Enter the real part of c1\n" );
  scanf("%d", &a1.real );

  printf("Enter the imaginary part of c1\n" );
  scanf("%d", &a1.img );

  printf("Enter the real part of c2\n" );
  scanf("%d", &a2.real );

  printf("Enter the imaginary part of c2\n" );
  scanf("%d", &a2.img );

  cd.real = a1.real +a2.real;
  cd.img = a1.img + a2.img;

  ab.real = a1.real - a2.real;
  ab.img = a1.img - a2.img;

  if(  cd.real == 0 || ab.img == 0 || (a1.img== -1* a2.img && a1.real == a2.real) || (a1.img == 0 && a2.img == 0)) {
    printf("True\n" );
  }else
    printf("False\n" );

return 0;
}
