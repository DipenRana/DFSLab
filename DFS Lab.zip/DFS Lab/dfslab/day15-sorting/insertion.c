#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void insertionSort(void *base, size_t nitems, size_t memSize)
{
    char *carray = (char *)base;
    unsigned int i;
    int j;

    for(i = 0; i < nitems; i++)
    {
        j = i;
        while(j > 0 && cmp(&carray[j * memSize], &carray[(j - 1) * memSize]) < 0)
        {
            byteSwap(&carray[j * memSize], &carray[(j - 1) * memSize], memSize);
            j--;
        }
    }
}


int cmp(const void *a, const void *b)
{
   const int *A = a, *B = b;   // A > B = 1, A < B = -1, (A == B) = 0
   return (*A > *B) - (*A < *B);
}

void byteSwap(void *a, void *b, size_t memSize)
{
    char temp[memSize];

    memcpy(temp, a, memSize);
    memcpy(a,b, memSize);
    memcpy(b, temp, memSize);
}

int main()
{
  int arr[] = {'a' , 'v', 'd' ,'g' , 'p', 's', 'A' ,'e', 'R' ,'z'};
  int i, j, n =sizeof(arr)/sizeof(int);
  insertionSort(arr,n,sizeof(int));

  for(int i=0; i< n; i++)
    printf(" %c ,", arr[i]);

    printf("\n" );
  return 0;
}
