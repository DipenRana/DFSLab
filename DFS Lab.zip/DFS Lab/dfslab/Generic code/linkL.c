#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define Malloc(n,type) (type *)malloc((unsigned) ((n)*sizeof(type)))
#define Realloc(loc,n,type) (type *)realloc( (char *)(loc),(unsigned) ((n)*sizeof(type)))

//Calculate size of buffer element
#define DATA_SIZE(y) sizeof(y[0])

//Calculate number of element in buffer 
#define Number_Node(x)  sizeof(x)/DATA_SIZE(x)


//Creating a new type

typedef void *  pVoid;


// Creating Node
 struct Node 
{
  /*void pointer*/
  pVoid iData;
  
  /*Node Pointer*/
  struct Node *pNextNode;
};
 
 
// Define the new type Node type and Node pointer
typedef  struct Node  NodeType, * NodePointer;

/* Pass the reference of the head pointer of a list and 
   an integer data. This function use to add the node at the End*/
int InsertNodeAtEnd(NodePointer * pHead, void *InputData, int SizeofData) 
{
	int iRetValue = -1;
	int iOffSet = 0;
	
	NodePointer pLastNode = NULL;
	NodePointer pNewNode = NULL;
	
	//Give the Address of first Node
	pLastNode  = *pHead;
	
	// Call malloc to allocate memory in heap for the new node
	pNewNode = malloc(sizeof(NodeType));
	
	if( pNewNode != NULL) //Check allocated memory
	{
		
		  pNewNode->iData = malloc(SizeofData); //put the desire Data
				  
		  //Copy the bytes of data as per the data types
				  
		 for (iOffSet = 0; iOffSet < SizeofData; iOffSet++)
         *((size_t *)(pNewNode->iData  + iOffSet)) =  *((size_t *)(InputData + iOffSet));
			  
		
		pNewNode->pNextNode  = NULL; //Give the Address of first Node
		
		iRetValue = 0; // Update the return value
		
	}
	// If there is no node in beginning
	if(pLastNode == NULL)
	{
		*pHead = pNewNode;
	}
	else 
	{
		// Find the address of last node
		while( pLastNode ->pNextNode != NULL)
		{
			pLastNode  = pLastNode ->pNextNode;
		}
	
	   // Assign last node address
	    pLastNode ->pNextNode = pNewNode;
 
	}
	
	return iRetValue;
}


/* Paas the reference of the head pointer of a list. This function use
to free the all allocated memory*/
void FreeAllocatedMemory(NodePointer  *pHead)
{
   NodePointer   pTmpNode = NULL;
   NodePointer   pFirstNode = NULL;
   //Assign  the Address of first node
   pFirstNode  = *pHead;
   
/*check if pFirstNode is NULL, then now list is empty,
so assign NULL to head and return.*/
   while (pFirstNode  != NULL)
    {
	 /*Save the pFirstNode in a pTmpNode node pointer*/ 
 
       pTmpNode = pFirstNode  ;
       
       /*Assign the address of next on your list*/	
       pFirstNode  = pFirstNode->pNextNode;
       
       //Free the data
       free(pTmpNode->iData);
       //Free the allocated memory
       free(pTmpNode );
       
    }
	//Assign NULL to the head pointer
	*pHead = NULL;
 
}

/* Pass the reference of the head pointer of a list and 
   an integer data*/
void DeleteNodeFromPosition(NodePointer * pHead,unsigned int iPosition)
{
	NodePointer pTmpNode = NULL;
	NodePointer pPreviousTmpNode = NULL;
	unsigned int iCount = 0;
	
    //Give the Address of first Node
	pTmpNode  = *pHead;
 
    for( iCount = 1; ((iCount < iPosition) && (pTmpNode!= NULL)) ; iCount++)
    {
		pPreviousTmpNode = pTmpNode;
    	pTmpNode  = pTmpNode ->pNextNode;
	}
	

      pPreviousTmpNode->pNextNode = pTmpNode->pNextNode;
	  free(pTmpNode);
	  pTmpNode = NULL;
	  
  return;
}

//Create a linked list of certain number of nodes
 
int CreateLinkedList(NodePointer *pHead , void *InputData, int SizeofData)
{

    int iRetValue = -1;
    int iOffSet = 0;
    NodePointer pNewNode = NULL;
    
        
        if((*pHead) == NULL)
        {
             // Call malloc to allocate memory in heap for the first node
              pNewNode = malloc(sizeof(NodeType));
              if( pNewNode != NULL) //Check allocated memory
              {
                  pNewNode->iData = malloc(SizeofData); //put the desire Data
                  
                  //Copy the bytes of data as per the data types
                  
                  for (iOffSet = 0; iOffSet < SizeofData; iOffSet++)
                  *((size_t *)(pNewNode->iData  + iOffSet)) =   *((size_t *)(InputData + iOffSet));
                  
                  pNewNode->pNextNode  = NULL; //Give the Address of first Node
                  
                  *pHead = pNewNode; /*Assign the address of 
                                      the first node to the head pointer*/
                  
                  iRetValue = 0; // Update the return value
        
    }
        }
        else
        {
            //Add the Node at the End
            iRetValue = InsertNodeAtEnd(pHead,InputData,SizeofData);
            
        }
    
    
    return iRetValue;
}



void main()
{
 NodePointer head=NULL;

 char a=10;
 for(int i=0;i<10;i++)
 {
     a=65+i;
    InsertNodeAtEnd(&head,&a,sizeof(a)); 
 }

 DeleteNodeFromPosition(&head,3);

  printf("\nLinked List is:\n");
  while (head != NULL)
  {
     printf("\n%c",*((char *)head->iData));
     head = head->pNextNode;
  }

}
