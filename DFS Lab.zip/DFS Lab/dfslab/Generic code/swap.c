#include <stdio.h>

void swap(void *a,void *b,size_t s)
{
    char temp,*a1=(char*)a,*b1=(char*)b;
    while(s--)
    {
    temp=a1[s];
    a1[s]=b1[s];
    b1[s]=temp;
    }
}


void main()
{
    char a='a',b='b';
    printf("%c %c\n",a,b);
    swap(&a,&b,sizeof(char));
    printf("%c %c",a,b);
}