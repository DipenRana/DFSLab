#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
 void *data;
 int top;
 size_t memberSize, totalElements;
} STACK;

void initStack (STACK *s, int memberSize,int totalElements)
{
  s->top = -1;
  s->memberSize = memberSize;
  s->totalElements = totalElements;
  s->data = malloc(totalElements*memberSize);
}

void freeStack(STACK *s)
{
    free(s->data);
    free(s);
}

int isEmpty(const STACK *s){
    if (s->top == -1)
        return 1;
    else
        return 0;
}

int push(STACK *s, const void *elements){
    //check is the stack is full
  if (s->top == s->totalElements - 1) {
    //if full, return 1 which would signal that the operation failed
    return 1;
  }
  s->top++;
  //calculate starting location for the new element
  void *target = (char*)(s->data + (s->top * s->memberSize));
  memcpy(target, elements, s->memberSize);
  return 0;
}

int pop(STACK *s, void *target)
{
    if (s->top == -1) {
    return 1;
  }
  void* source = (char*)s->data + (s->top*s->memberSize);
  s->top--;
  memcpy(target, source, s->memberSize);
  return 0;
}

int main()
{
    STACK A;
    int check;
    char out=1;
    char x ='a';
    initStack(&A,sizeof(char),11);
    check=push(&A,&x);
    printf("%d\n",check);
    
    for(int i=65;i<79;i++)
    {
        check=push(&A,&i);
        printf("%c\n",i);

    }
    
    for(int i=0;i<13;i++)
    {
        check=pop(&A,&out);
        printf("%d %d %c\n",check,i,out);

    }
 return 0;   
}