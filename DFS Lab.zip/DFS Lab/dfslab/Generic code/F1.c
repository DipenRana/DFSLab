#include<stdlib.h>
#include<string.h>

#define Malloc(n,type) (type *)malloc((unsigned) ((n)*sizeof(type)))

#define Realloc(loc,n,type) (type *)realloc( (char *)(loc),(unsigned) ((n)*sizeof(type)))

#define Calloc(n,type) (type *)calloc(unsigned(n), sizeof(type))

int** Multi_int(int rows, int cols)
{
	int **a, i;
	a = (int **)malloc(rows*sizeof(int *));
	for(i=0;i<rows;i++)
	a[i] = (int *)malloc(cols*sizeof(int));
	return a;
}

char** Multi_string(int rows, int cols)
{
	char **a;
	a = (char **)malloc(rows*sizeof(char *));
	for(int i=0;i<rows;i++)
	a[i] = (char *)malloc(cols*sizeof(char));
	return a;
}

void Free(void **a,int rows)
{
	for(int i=0;i<rows;i++)
	{
		free(a[i]);
	}
	free(a);
}

//qsort((void*)arr, size, sizeof(arr[0]), compare_L); 
int comparator(const void *p, const void *q) 
{ 
    // Get the values at given addresses 
    int l = *(const int *)p; 
    int r = *(const int *)q; 
  
    return (l-r); 
   
}

int compare_string_static (const void *a, const void * b)  
{ return ( *(char *)a - *(char *)b ); }

int string_cmp(const void *a, const void *b) 
{ 
    const char **ia = (const char **)a;
    const char **ib = (const char **)b;
    return strcmp(*ia, *ib);
}

//Decressing Odd Icreasing Even 
int comparator_Od_Ei(const void *p, const void *q) 
{ 
    // Get the values at given addresses 
    int l = *(const int *)p; 
    int r = *(const int *)q; 
  
    // both odd, put the greater of two first. 
    if ((l&1) && (r&1)) 
        return (r-l); 
  
    // both even, put the smaller of two first 
    if ( !(l&1) && !(r&1) ) 
        return (l-r); 
  
    // l is even, put r first 
    if (!(l&1)) 
        return 1; 
  
    // l is odd, put l first 
    return -1; 
} 