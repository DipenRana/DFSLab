#include<stdio.h>
#include<stdlib.h>


/* Define struct of Binary Tree */
struct Tree{
  /*Data field*/
  int data;
  /*Pointer field*/
  struct Tree*left,*right;
};

struct Stack{
    int visit;
  /*Data field*/
  struct Tree*link;
  /*Pointer field*/
  struct Stack*next;
};

/*Function Declaration Section*/
void insert_node(struct Tree**,int);
struct Tree* free_node(struct Tree*);

struct Tree*create_node(int);
void pop(struct Stack**);
void push(struct Tree*,struct Stack**);

void preorder_show(struct Tree*);
void preorder_traversal(struct Tree*,struct Stack**);

void postorder_show(struct Tree*);
void postorder_traversal(struct Tree*,struct Stack**);




/*  Create newly Binary tree Node.*/

struct Tree*create_node(int value){
  /*Create memory block of size of struct Tree.*/
  struct Tree*new_node=(struct Tree*)malloc(sizeof(struct Tree));
  if(new_node!=NULL){
    new_node->data=value;
    new_node->left=new_node->right=NULL;
    return new_node;
  }else{
    printf("\n Memory overflow.");
    return NULL;
  }  
}
/* Show Binary Tree node data using this function */
void preorder_show(struct Tree*temp){
  if(temp){
    printf("  %d",temp->data);
    preorder_show(temp->left);
    preorder_show(temp->right);
  }else
  return;
}
/*Preorder traversal of Given Binary tree */
void preorder_traversal(struct Tree*temp,struct Stack**top){
  if(temp==NULL){
    printf("\n Empty Tree");
    return;
  }
  printf("\n    Preorder Data Using Stack :");
  /*This loop execute until when temp pointer and top pointer are not NULL*/
  while(temp!=NULL || *top!=NULL){
    if(temp!=NULL){
        /*print data*/
        printf("  %d",temp->data);
        /*insert stack data*/
        push(temp,top);
        /*visit left node*/
        temp=temp->left;
    }
    else{
      temp=(*top)->link;
      pop(top);
      /*visit right node*/
      temp=temp->right;
    }
  }

}

/* Show Binary Tree node data using this function */
void postorder_show(struct Tree*temp){
  if(temp){
    postorder_show(temp->left);
    postorder_show(temp->right);
    printf("  %d",temp->data);
  }else
  return;
}

/*Tree Postorder traversal using stack*/
void postorder_traversal(struct Tree*temp,struct Stack**top){
  if(temp==NULL){
    printf("\n Empty Tree");
    return;
  }
  printf("\n   Postorder Data Using Stack :");
  /*insert first node of stack*/
  push(temp,top);
  struct Stack*store=NULL;
  /*This loop execute until when temp pointer are not NULL*/
  while(temp!=NULL){
    store=*top;
    if(store->visit==0){
      if(temp->right!=NULL){
        (store->visit)++;
        /*insert stack data*/
        push(temp->right,top);
      }
      if(temp->left!=NULL){
        (store->visit)++;
        /*insert stack data*/
        push(temp->left,top);
      }
      if(store->visit==0){
        printf("  %d",temp->data);
        temp=NULL;
        pop(top);
      }
    }
    else{
      printf("  %d",temp->data);
      temp=NULL;
      pop(top);
    }
    if(*top!=NULL)
      temp=(*top)->link;
  }
}



/*Push operation on stack elements*/
void push(struct Tree*node,struct Stack**top){
  /*Create memory block*/
  struct Stack*new_node=(struct Stack*)malloc(sizeof(struct Stack));
  if(new_node!=NULL){
    new_node->link=node;
    new_node->next=*top;
    new_node->visit=0;
    *top=new_node;
  }else{
    printf("\n Memory overflow.");
    return ;
  }  
}

/*Deleting a top element of stack*/
void pop(struct Stack**top){
  if(*top!=NULL){
    struct Stack *remove = *top;
    *top=(*top)->next;
    remove->link=NULL;
    remove->next=NULL;
    free(remove);
    remove=NULL;    
  }
}
/* Help of this function Free Binary Tree Nodes */
struct Tree* free_node(struct Tree*temp){
 if(temp){
  temp->left=free_node((temp->left));
  temp->right=free_node(temp->right);
  free(temp);
  temp=NULL;
}
return NULL;
}

/*Main function*/
int main(){
  /* Start execution */
  /* Binary Tree struct pointer*/
  struct Tree *root = NULL;
  /*Stack pointer*/
  struct Stack *top=NULL;
  /*inserting following data*/
  root                      = create_node(1);
  root->left                = create_node(2);
  root->right               = create_node(3);
  root->left->left          = create_node(4);
  root->right->left         = create_node(8);
  root->right->right        = create_node(9);
  root->right->right->right = create_node(30);
  root->right->left->right  = create_node(10);
  /*Print Binary Tree nodes*/
  printf("\n Preorder Data Using Recursion:");
  preorder_show(root);
  preorder_traversal(root,&top);

  printf("\n Postorder Data Using Recursion:");
  postorder_show(root);
  postorder_traversal(root,&top);
  /*Free Binary Tree Node*/
  free_node(root);
  return 0;
  /* End execution of program */
} 
