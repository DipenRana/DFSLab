#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
	int len;
	char arr[85];

	
	int i=1,j=0, k=1, pr = 1;

	arr[0]='-';
	printf("Enter the string.\n");
	scanf("%c", &arr[i]);
	while(i <= 80){
		i++;
		scanf("%c", &arr[i]);
		if(arr[i] == '\n')
			break;

		
		if( tolower(arr[i]) == tolower(arr[k]) ) {
			pr = i-k;
			k++;
		} else {
			k = 1;
		}
	}

	i--;
	if(i%pr == 0) {
		printf("Period of string is = %d\n", pr );
	} else {
		printf("Period of string is = %d\n", i );
	}


	return 0;
}