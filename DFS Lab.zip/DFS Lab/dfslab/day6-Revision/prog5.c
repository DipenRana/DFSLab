#include <stdio.h>

void cantorForm(int x) {
	int p, q, i=2;
	int sum =0, cnt, y;
	if(x == 1) {
		p=1;
		q=1;
		printf("%d/%d\n", p,q );

	} else{

	sum =1;
	cnt =2; 
	while (sum < x) {
		if( sum + cnt < x)
		{
			sum += cnt;
			cnt++;
			i++;
		} else {
			if(i%2 == 0 || sum == 1)
			{
				p = 1;
				q = i; 
				y = x - sum -1;
				while(y != 0){
					p++;
					q--;
					y--;
				}
			} else
			{
				p = i;
				q = 1;
				y = x - sum -1;
				while(y != 0){
					p--;
					q++;
					y--;
				}
			}
			sum += cnt;
			i++;
		}

	}

	printf("%d/%d\n", p, q );

	}
}

int main() {
	int arr[10], p, q;
	int n;

	printf("Enter size of interger array\n");
	scanf("%d", &n);

	for(int i=0; i < n ; i++) {
		scanf("%d", &arr[i]);
	}


	for(int i=0; i < n; i++)
		cantorForm(arr[i]);


	return 0;
}