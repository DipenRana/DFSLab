#include <stdio.h>


int calc(int n) {
	int sum =0;

		while(n != 0) {
			sum += n%10;
			n= n/10;
		}
		if( sum /10 != 0) {
			sum = calc(sum);
		}

	return sum;
}

int main() {
	int n;
	int sup= 0;
	printf("Enter an integer\n");
	scanf("%d", &n);

   sup = calc(n);

   printf("Superdigit of %d = %d\n", n, sup );
	return 0;
}