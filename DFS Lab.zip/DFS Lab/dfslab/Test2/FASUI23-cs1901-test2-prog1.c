/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 27-Sep-19
  Program description: Prog1 : Matrix multiplication.
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>


void multiplicationSquare(unsigned long *A,int n) {
  unsigned long *temp = (unsigned long*) malloc(n*n*sizeof(unsigned long));
  unsigned long sum = 0;

  for(int i =0; i < n; i++) {
    for(int j=0; j< n; j++) {
      sum = 0;
      for(int k =0; k< n; k++){
        sum += A[i*n+k] * A[k*n+j];
      }
      temp[i*n+j] = sum;
    }
  }

  for(int i=0; i< n*n; i++){
    A[i] = temp[i];
  }

  free(temp);
}

void matrixMutli(unsigned long *A,int n, int pow) {
  unsigned long *arry = (unsigned long*) malloc(n*n*sizeof(unsigned long));

  int p = pow, count =0, x=1;

  if(pow == 0){
    for(int i =0; i < n; i++) {
      for(int j=0; j< n; j++) {
        if(i==j)
          A[i*n+j] = 1;
        else
          A[i*n+j] = 0;
      }
    }
    return;
  } else if(pow == 1) {
    return;
  }

  while(p > 1){
    p = p/2;
    count++;
    x*=2;
  }

  for(int i=0; i< n*n; i++){
    arry[i] = A[i];
  }

  //printf("Count= %d, X= %d\n",count,x );

  while (count ) {
    multiplicationSquare(arry,n);
    for(int i=0; i< n*n; i++) {
       printf("%lu  ",arry[i] );
       if((i+1)%n == 0)
         printf("\n" );
     }
    count--;
  }

  pow = pow - x;
  //printf("Pow = %d\n",pow );

  matrixMutli(A,n,pow);

  unsigned long *temp = (unsigned long*) malloc(n*n*sizeof(unsigned long));
  unsigned long sum = 0;
  for(int i =0; i < n; i++) {
    for(int j=0; j< n; j++) {
      sum = 0;
      for(int k =0; k< n; k++){
        sum += A[i*n+k] * arry[k*n+j];
      }
      temp[i*n+j] = sum;
    }
  }

  for(int i=0; i< n*n; i++){
    A[i] = temp[i];
  }

  free(arry);
  free(temp);
/*  for(int i=0; i< n*n; i++) {
    printf("%d  ",arry[i] );
    if((i+1)%n == 0)
      printf("\n" );
  }
  */
}

int main() {
  int pow;
  char c;
  int row[10],n,m;
  int num =0;
  unsigned long *arr;
  int i =0;
  int temp;


  printf("Enter the pow.\n" );
  do{
    scanf("%c", &c );
    if(c == ' ' )
    {  temp = num;
      num = 0;
    }
    else if(c == '\n'){
      pow = num;
    } else {
      num = num *10 + c - 48;
    }
  } while (c != '\n');

  printf("Enter the matrix rows.\n" );
  num = 0;
  do{
    scanf("%c", &c );
    if(c == ' '){
      row[i] = num;
      i++;
      num =0;
    } else if(c == '\n') {
          row[i] = num;
          i++;
          num = 0;
    } else {
        num = num * 10 + c - 48;
    }
  } while(c != '\n');

  n = i;

  arr = (unsigned long *) malloc(n*n*sizeof(unsigned long));
  int k = 0;
  for(int j =0; j< n; j++) {
    arr[k] = row[j];
    k++;
  }

  for(int i = 1; i < n ; i++) {
    num = 0;
    do{
      scanf("%c", &c );
      if(c == ' '){
        arr[k] = num;
        k++;
        num =0;
      } else if(c == '\n') {
            arr[k] = num;
            k++;
            num = 0;
      } else {
          num = num * 10 + c - 48;
      }
    } while(c != '\n');
  }

  matrixMutli(arr,n, pow);

  printf("Resulting matrix\n\n" );
  for(int i=0; i< k; i++) {
    printf("%lu  ",arr[i] );
    if((i+1)%n == 0)
      printf("\n" );
  }

  free(arr);
  return 0;
}
