/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 27-Sep-19
  Program description: Prog3 : Tree merging
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode
{
	int data;
	struct TreeNode *left, *right, *parent;
}TreeNode;


void printTree(TreeNode *root) {
	if(root == NULL)
		return;
	printf("Root: %d",root->data);
	//printf("LC: %d    RC:%d",&(root->left).data,&(root->right).data);

	printTree(root->left);
	printTree(root->right);

}

TreeNode* buildTree(int *arr, int n) {
    TreeNode *node = (TreeNode *) malloc(sizeof(TreeNode));

      node->data = arr[n*3];
      //printf("N =%d\n", n );
      //printf("Left =%d\n", arr[n*3+1]);
      if(arr[n*3+1] != -1)
        node->left = buildTree(arr,arr[n*3+1] -1);
      else
        node->left = NULL;

        //printf("right =%d\n", arr[n+2]);
      if(arr[n*3+2] != -1)
        node->right = buildTree(arr,arr[n*3+2] -1);
      else
        node->right = NULL;

    return node;

}

TreeNode* mergeTree(TreeNode *T1,TreeNode *T2){
    TreeNode *A,*B;
    char c;
    A=T1;
    B=T1;
   while(A->left != NULL || B->right != NULL){
     A = A->left;
     B = B->right;
   }
   printf("Got Null\n" );
   scanf("%c", &c);
   if(A->left == NULL)
    A->left = T2;
    else if(B->right == NULL)
      B->right = T2;

    return T1;
}

int main() {
  TreeNode **root,*result;
  int k,n;
  char  c;
  int num = 0;
  int *size;

  printf("Enter the number of trees.\n" );
  do{
    scanf("%c", &c );
    if(c == ' ' || c == '\n'){
      k = num;
    } else {
      num = num *10 + c - 48;
    }
  } while (c != '\n');
  root = (TreeNode **) malloc(k*sizeof(TreeNode *));
  size = (int *) malloc(k);

  for(int m =0 ; m < k; m++) {
        printf("Enter no of nodes in %d tree\n",m );
        num = 0;
        do{
          scanf("%c", &c );
          if(c == ' ' || c == '\n'){
            n = num;
          } else {
            num = num *10 + c - 48;
          }
        } while (c != '\n');
        size[m] = n;
        int *arr = (int *) malloc(n*3*sizeof(int));
        int j=0;
        for(int i=0; i<n ; i++) {
          num =0;
          do{
            scanf("%c", &c );
            if(c == ' '){
              if(num == -29)
                num = -1;
              arr[j] = num;
              j++;
              num =0;
            } else if(c == '\n') {
                if(num == -29)
                  num = -1;
                  arr[j] = num;
                  j++;
                  num = 0;
            } else {
                num = num * 10 + c - 48;
            }
          } while(c != '\n');
        }


        root[m] = buildTree(arr,0);

        printTree(root[m]);
        printf("\n\n" );
  }

  printf("Merging two trees");
  result = root[0];
  for(int i = 1; i<k; i++) {
    printf("Merging two trees");
        result = mergeTree(result,root[i]);
  }

  printTree(result);


  return 0;
}
