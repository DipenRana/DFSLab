/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 27-Sep-19
  Program description: Prog2 : Generic overspill stack
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>


typedef struct {
  void *elements;
  size_t elements_size, num_elements, max_elements;
}STACK;

void initStack(STACK *s, int elem_size, int max) {
    s->elements = (void *) malloc(elem_size);
    s->num_elements = 0;
    s->max_elements = max;
}

int isEmpty(const STACK *s) {
    if(s->num_elements == 0)
      return 1;
    else
      return 0;
}

void freeStack(STACK *s) {
  free(s);
}

void push(STACK *s, const void *eptr) {

    if(s->num_elements==s->max_elements) {
      printf("Stack Overflow\n" );
    } else {
      s->elements = (void *) realloc(s->elements, s->elements_size* s->num_elements);
      void *a = &s + s->elements_size * s->num_elements;
      memcpy(a, eptr, s->elements_size);
      s->num_elements++;
      //printf("%ld\n",s->num_elements );
    }
}

void pop(STACK *s, void *eptr) {

  if(s->num_elements == 0){
    printf("Underflow\n" );
    return;
  }
  void *top = &s + s->elements_size * s->num_elements;
  eptr = top;
  s->num_elements--;
}

int main() {
    STACK *s= (STACK *)malloc(sizeof(STACK));
    int spc = 0,max, tol;
    unsigned int sz;
    char c,type;
    int num = 0;

scanf("%c", &c );
type = c;

switch (c) {
  case 'i': sz = sizeof(int);
            break;
  case 'f': sz = sizeof(float);
            break;
  case 'c': sz = sizeof(char);
            break;
}

    scanf("%c", &c );
    do{
      scanf("%c", &c );
      if(c == ' ' )
      {  spc++;
          max = num;
         num = 0;
      }
      else if(c == '\n'){
        tol = num;
      } else {
        num = num *10 + c - 48;
      }
    } while (c != '\n');

    initStack(s, sz, max);



    return 0;
}
