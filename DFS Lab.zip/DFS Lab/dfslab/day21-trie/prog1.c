#include "trie.h"
#include "common.h"

int main() {

  char *pr,c;
  int n;

  pr = (char *) malloc(sizeof(char));
  init_trie();
  printf("Enter the value of n\n" );
  scanf("%d",&n );
  printf("Enter the string\n" );

  int i = 0, len = 0;
  do {
    c = getchar() ;
    if(c >= 'a' && c <= 'z' || c == '\n' || c <=' '){
      len++;
    }
    pr[i] = c;
    i++;
    pr = (char *) realloc(pr, (i+1)*sizeof(char));


  } while(c != EOF) ;
  pr[i] = '\0';


  char *ch = (char *)malloc((n+1)*sizeof(char));
  for(int i = 0; i <strlen(pr) - n; i++) {
    int j = 0;
    while(j < n){
      if(pr[i+j] == '\n' || pr[i+j] == ' ')
        break;
      ch[j] = pr[i+j];
      j++;
    }
    ch[j] = '\0';
    if(j == n)
      insert_string(ch);
  }
  int max = trie_dfs();

  printf("Max frequency =%d\n",max );
  return 0;
}
