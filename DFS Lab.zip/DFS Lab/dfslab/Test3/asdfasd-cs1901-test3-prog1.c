/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 22-Oct-19
  Program description: Prog1 Frech flag
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MIN(a,b) (((a)<(b))?(a):(b)) // return min of a and b

int main() {
  int n;      //no of bands
  char *str, p;   // string of bands, char for stale newline char

  printf("Enter number of bands\n" );
  scanf("%d%c", &n, &p );       //scan number of bands and stale newline.

  str = (char *)malloc(n*sizeof(char));    //allocating dynamic memmory to str
  char ch;
  int spc = 0,
      bands = 0,
      ind = 0,
      ws = 0, rs = 0, bs = 0 ;
  do {
    ch = getchar() ;
    if(ch == 'W' || ch == 'R' || ch == 'B'){
      str[ind] = ch;
      switch (ch) {                 //calculating number of white, red and blue bands.
        case 'W': ws++; break;
        case 'R': rs++; break;
        case 'B': bs++; break;
      }
      bands++;
      ind++;
    } else if(ch == ' ' || ch == '\n') {
      spc++;
    } else {
      printf("You Entered an invalid input \n" );
      return 0;
    }
  } while(ch != '\n') ;   //scanning input until newline is hit

  if(bands != n) {
    printf("You entered wrong number of bands\n" );
    return 0;
  }

  int min, sqr;
  min = MIN(ws,rs);
  min = MIN(min,bs);

  if(min == 0) {
    return 0;
  } else {
    sqr = sqrt(min);
    for(int i = 0; i< sqr; i++) {     //printing the output in desired format
      for(int j = 0; j< sqr; j++)
        printf("B ");
      for(int j = 0; j< sqr; j++)
        printf("R ");
      for(int j = 0; j< sqr; j++)
        printf("W ");
      printf("\n");
    }
  }

  return 0;
}
