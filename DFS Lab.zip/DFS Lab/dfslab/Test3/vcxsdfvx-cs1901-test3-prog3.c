/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 22-Oct-19
  Program description: Prog3 computing the h-index of the scientist
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int partition(int *arr,int a, int size) {             //partition function for QuickSort
  int i = a-1, j = size-1, v = arr[size-1], x;

  while(1) {
    do i = i+1; while(arr[i] < v);
    do j = j-1; while(arr[j] > v);
    if(i >= j) break;
    x = arr[i]; arr[i] = arr[j]; arr[j] = x;
  }
  x = arr[i]; arr[i] = arr[size-1]; arr[size-1] = x;
  return i;
}

void QuickSort(int* arr, int i, int size) {           //QuickSort Algorithm
  if( i < size){
    int pvt=  partition(arr,i, size);
    QuickSort(arr,i, pvt-1);
    QuickSort(arr, pvt + 1,size);
  }
}

int binaryCheck(int *arr,int i, int size) {           // Checking for the index value in binary search fashion
  int r = size-1;
  int l = i;

  while(r>=l) {
    i = l + (r - l)/2;
    if( i >= size) return 0;
    if(arr[i] >= size-i){
      r = i-1;
    } else{
      l = i+1;
    }
  }

    return l;
}

int main(int ac, char *av[]) {

  int *arr = (int *)malloc((ac-1)*sizeof(int)),
      n = ac-1;

  for (int  i =1;i < ac;  i++) {      // input conversion
    arr[i-1] = atoi(av[i]);
  }

  QuickSort(arr,0,n);       // Sorting input
  // for(int i = 0; i< n; i++)
  //   printf("%d \n", arr[i]);

  int ans = binaryCheck(arr,0,n);     //Computing answer  Answer is size of array - (return value of binaryCheck function)

  printf("%d",n-ans );

  return 0;
}
