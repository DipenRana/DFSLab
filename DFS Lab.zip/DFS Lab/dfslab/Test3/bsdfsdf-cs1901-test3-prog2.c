/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 22-Oct-19
  Program description: Prog2 BST to SearchMaxHeap
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct{         //Tree Node Structure
  int data;
  int left;
  int right;
}Node;

void swapData(Node *tr, int i, int j) {   // swap data in tree of nodes i and j
  int temp = tr[i].data;
  tr[i].data = tr[j].data;
  tr[j].data = temp;
}

int main(int ac, char *av[]) {
  FILE *fp;
  int n;    // number of nodes
  Node *tree;
  double index;

  if(ac < 1)        //no of arguments check.
  {  printf("Invalid file name\n" );
    return 0;
  }

  if (NULL == (fp = fopen(av[1], "r"))) // checking if file is opend successfully
  {
        printf("Error opening text file\n");
        return 0;
  }

  fscanf(fp,"%d\n",&n);
  tree = (Node *) malloc(n*sizeof(Node));    // alternate implementation of Tree

  char c;
  int num = 0;
  for(int i=0; i<n ; i++) {       // Reading the BST tree from file
      fscanf(fp,"%d",&num);
      tree[i].data = num;
      fscanf(fp,"%d",&num);
          tree[i].left = num;
      fscanf(fp,"%d\n",&num);
          tree[i].right = num;
  }

  for(int i = 0; i<n; i++){
      if(tree[i].left < n && tree[i].right < n);
          //  printf("%d %d %d \n",tree[i].data,tree[i].left,tree[i].right);
      else
      {
        printf("Invalid input enterd");
        return 0;
      }
  }

      swapData(tree,0,n-1);
      if(tree[n-2].data > tree[n-1].data)
        swapData(tree,n-2,n-1);

      index = log2(n)+1;
      int x =(int)index;
      int c1, c2;

      for(int i=1;i<x;i++)
      {
        c1=(2*i)+1; //child 1
        c2=(2*i)+2; //child 2
        if((tree[i].data < tree[c2].data)&& (c2<n))   //swapping the data if parent data is smaller then right child
        {
          swapData(tree,i,c2);
        }
        else if((tree[i].data < tree[c1].data) && (c1<n))   //swapping the data if parent data is smaller then left child
        {
          swapData(tree,i,c1);
        }
      }

      for(int i=0;i<n;i++)        //printing the tree
        printf("%d %d %d\n",tree[i].data,tree[i].left,tree[i].right);


  return 0;
}
