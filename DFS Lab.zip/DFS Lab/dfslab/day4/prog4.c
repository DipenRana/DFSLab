#include<stdio.h>

int main(){
  File *ptr;
  char line[100];

  if ((ptr = fopen("prog4.c","r")) == NULL) {
    printf("Error opening file\n" );
    return 0;
  }

  fscanf(fptr, "%[^\n]",line);
  while(){

  }
}
