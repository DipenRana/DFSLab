#include <stdio.h>

#define imply(x,y) (!x || y)
#define swap(x,y) { int temp; temp=x; x=y; y=temp;}
#define min(x,y) (x>y)? y : x
#define max(x,y) (x<y)? y : x
#define infiny(x) while(1) printf("%d", x );
#define LSB(x) (1 & x)

int main() {

  int a = 5, b=7;

  printf("Imply %d\n", imply(a,b) );
  swap(a,b);
  printf("A= %d, B= %d\n",a,b );
  printf("Min = %d\n", min(a,b) );
  printf("Max = %d\n", max(a,b) );
  printf("LSB of A =%d\n", LSB(a));
  getchar();
  infiny(a);
  return 0;
}
