#include <stdio.h>

int main() {
  int sticks =11, sum, turn, x, y;

  printf("There are 11 sticks. Each (you and computer can take 1 to 3 sticks at a time)\n" );
  printf("Last one to pick the stick will loose\n" );
  printf("Enter 1 for your turn and 0 for computer turn\n" );
  scanf("%d", &turn );

  if (turn !=0 && turn!=1) {
    printf("Invalid turn entered!!!!\n" );
    return 0;
  }

  sum = 0;

  while(sticks > 1)
  {
    printf("Sticks: %d\n", sticks );
    if(turn == 1) {
      printf("Enter no of sticks you want to remove.\n" );
      scanf("%d", &x );
      if(x > 0 && x < 4) {
        sum += x;
      } else {
        printf("Invalid number of sticks cannot be removed.\n" );
      }
    } else if(turn == 0) {
      if (sticks ==11) {
        x=2;
      } else if(sum < 6) {
        x = sticks % 5;
        x = x % 4;
      } else {
        x = sticks - 1;
        x = x % 4;
      }
      if (x == 0)
       x=1;
      printf("Computer chooses %d sticks\n", x );
      sum +=x;
    }
    sticks = sticks - x;

    if (turn == 1)
      turn =0;
    else if(turn == 0)
      turn = 1;
  }

  printf("Sticks remaining: %d\n", sticks );

  if( turn == 1)
  printf("You loose to computer\n" );
  else if (turn == 0){
    printf("You won!!!!\n" );
  }

return 0;
}
