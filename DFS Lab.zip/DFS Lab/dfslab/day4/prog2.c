#include <stdio.h>

int isPrime(int x) {
  int count=0;

  for( int i=1; i<=x/2 ; i++){
    if(x%i == 0) {
      count++;
    }
  }
  if(x==1)
    return 0;
  else if(count >1 ) {
    return 0;
  } else {
    return 1;
  }
}

int main() {
   char pass[30];
   int i=0,low = 0, up =0, digit = 0 , spec = 0;
   printf("Enter the password:\n" );

   do{
     pass[i]=getchar();
        if(pass[i]!='\r'){
            printf("*");
        }
        else if(pass[i] >= 'a' && pass[i] <= 'z')
          low++;
        else if(pass[i] >= 'A' && pass[i] <='Z')
          up++;
        else if(pass[i] >= '0' && pass[i] <= '9')
          digit++;
        else
          spec++;
        i++;
   } while(pass[i-1] != '\n');

   if( isPrime(low) && isPrime(up) && isPrime(digit) && isPrime(spec)) {
     printf("You entered Strong Password\n" );
   } else
    printf("Weak Password\n" );

  return 0;
}
