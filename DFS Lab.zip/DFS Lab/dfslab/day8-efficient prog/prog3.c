#include<stdio.h>
#include<unistd.h>

#define fib(x,y) (x+y)

int main() {
  unsigned long a=0,b=1, i = 1,temp;

  while(i<=1000){
    system("clear");
    printf("%lu\n",fib(a,b));
    sleep(1);
    temp =b;
    b = a+b;
    a = temp;
    i++;
  }
  return 0;
}
