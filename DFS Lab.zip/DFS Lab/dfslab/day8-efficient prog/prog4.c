#include<stdio.h>
#include<stdlib.h>

int isPrime(int x) {
  int flag=-1;
  int i;
  for(i=2;i*i<x;i++)
  {
    if(x%i==0)
    {
      break;
    }
    else
      flag=1;
  }
  return flag;
}

int main() {
  int n,fact=1,pp=2;

  printf("Enter the value of n\n" );
  scanf("%d", &n );

  for(int i=2; i<n+2; i++) {
    if(isPrime(i)) {
      printf("%d\n", i );
    }
    fact *= pp++;
    printf("Fact of i = %d\n", fact );
  }

  return 0;
}
