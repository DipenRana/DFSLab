#include<stdio.h>
#include<stdlib.h>

int main(){
  int n;
  int *arr;

  printf("Enter size of arr\n" );
  scanf("%d", &n );
  arr = (int *) malloc(n*sizeof(int));
  int x,count=0;
  for(int i=0;i<n;i++){
    scanf("%d", &x );
    if(i!= 0 && x != arr[count-1])
    { arr[count] = x;
      count++;
    } else if (i==0) {
      arr[count] = x;
      count++;
    }
  }

  for(int i =0; i<count; i++)
    printf("%d\n", arr[i] );
}
