#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#define DURATION(start, end) ((end.tv_usec - start.tv_usec) +(end.tv_sec - start.tv_sec) * 1000000)

struct Node {
  int x;
  struct Node *ptr;
};



int main(int argc, char* argv[]) {
  int n, *arr, x;
  struct timeval start_time, end_time;

  struct Node *head, *temp, *new;
  if(gettimeofday(&start_time, NULL) == -1)
    printf("gettimeofday failed");
  srand(time(0));

  printf("argc =%d\n", argc );

  n = atoi(argv[1]);
  arr = (int *) malloc(n*sizeof(int));
  printf("N = %d\n", n);
  for(int i=0;i<n;i++){
    arr[i] = rand() % 10000 + 1;
  }

  for(int i=0; i<n; i++){
    for(int j=0; j < i; j++){
      if(arr[i] < arr[j]) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
    }
  }
  for(int i=0;i<n;i++){
    printf("%d  ", arr[i] );
  }

  if(gettimeofday(&end_time, NULL) == -1)
    printf("gettimeofday failed");

  printf("\nTime taken for array impl. = %d micro sec\n", (int) DURATION(start_time, end_time));

  getchar();

  if(gettimeofday(&start_time, NULL) == -1)
    printf("gettimeofday failed");

  head = (int *)malloc(n * sizeof(int));
  head->ptr = NULL;
  head->x = rand() % 10000 + 1;

  for(int i=1;i<n;i++){
    temp = head;
    x = rand() % 10000 + 1;
    new = (int *)malloc(n * sizeof(int));
    new->ptr = NULL;
    while (  temp->ptr != NULL) {
      if(temp->x > x){
        new->x = temp->x;
        temp->x = x;
        new->ptr = temp->ptr;
        temp->ptr = new;
        break;
      }
      temp=temp->ptr;
    }

    if(temp->ptr == NULL) {
      temp->ptr = new;
      new->x = x;
    }
  }

  temp = head;
  while (temp != NULL) {
    printf("%d  ",temp->x );
    temp = temp->ptr;
  }

  if(gettimeofday(&end_time, NULL) == -1)
    printf("gettimeofday failed");

  printf("\nTime taken for linked list impl. = %d micro sec\n", (int) DURATION(start_time, end_time));

  return 0;
}
