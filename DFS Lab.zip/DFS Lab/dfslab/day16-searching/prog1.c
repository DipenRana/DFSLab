#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//#define Malloc(n,type) (type *)malloc((unsigned)(n* sizeof(type)))

struct Node {
  void *data;
  struct Node *next;
};

void push(struct Node **head, void *newData, size_t dataSize) {

  struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
  newNode->data = (char *) malloc(dataSize);
  newNode->next = *head;

  memcpy(newNode->data,newData,dataSize);

  *head = newNode;
}

void printList(struct Node *node, void (*fptr )(void*))  {
  while(node != NULL) {
      (*fptr)(node->data);
      node=node->next;
  }
}

void printInt(void *x) {
  printf("%d  ",*(int *) x );
}


void printFloat(void *x) {
  printf("%f  ",*(float *) x );
}

int cmp(const void *a, const void *b)
{
   const int *A = a, *B = b;   // A > B = 1, A < B = -1, (A == B) = 0
   return (*A > *B) - (*A < *B);
}

int main() {
  struct Node *list1 = NULL, *list2 = NULL;
  int arr1[] = {15, 6 , 6 , 8 , 6 ,7 , 12 , 35 , 456};
  int arr2[] = {6, 8 , 6 , 7};
  int count = 0;
  int n = sizeof(arr1)/sizeof(int),
      m = sizeof(arr2)/sizeof(int);;

  for(int i=0; i < n; i++)
    push(&list1, &arr1[i],sizeof(int));

  for(int i=0; i < m; i++)
    push(&list2, &arr2[i],sizeof(int));

  //printg the lists
    printList(list1,printInt);
  printf("\n\n" );
    printList(list2, printInt);


    printf("\n%d  %d\n",n,m );

  if(n > m) {
    struct Node *start = list2;
    for(int i = 0; i < n; i++){
      if(cmp(list1->data,list2->data)) {
          count++;
          list2 = list2->next;
          if(count == m)
          {  printf("List 2 is sublist of List 1\n" );
              return 0;
          }
      } else {
        list2 = start;
        count = 0;
      }
      list1 = list1->next;
    }
  }


    printf("No sublist\n" );


  return 0;
}
