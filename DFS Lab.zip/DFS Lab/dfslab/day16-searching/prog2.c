#include<stdio.h>
#include <stdlib.h>

int Breakable(int x, int tol) {
  if(x >= tol)
    return 1;
  else
    return 0;
}

int main(){
  int tol;
  int x = 1,count =0;
  printf("Enter tolerance level of metal sheet\n" );
  scanf("%d", &tol );
int mid;
  while (!Breakable(x,tol)) {
    x *=3;
    count ++;
    printf("Trial #%d: %d\n",count,x );
  }
  int lb = x/3, ub = x;
  mid = (ub + lb)/2;
  while(ub>=lb) {
    mid = (ub + lb)/2;
    count++;
    printf("Trial #%d: %d\n",count,mid );
    if(Breakable(mid,tol)){
      ub = mid -1;
    } else {
      lb = mid +1;
    }
  }
  if(!Breakable(mid,tol))
    mid = mid+1;
  printf("Tolerance = %d\n",mid );
  return 0;
}
