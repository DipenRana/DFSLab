/*
 * Author: Dipen Rana (CS1901)
 * Purpose: Given a set of distinct positive integers A as user input, write a program to partition A into
 *			an arbitrary number of distinct and non-null subsets A1, A2, . . . , An (n ≥ 2, Sn
 *			i=1 Ai = A, 
 *			Ai 6= ∅ and Ai ∩ Aj = ∅) such that the following function is maximized.
 *			F(A1, A2, . . . , An) = BAN D(BX OR(A1), BX OR(A1), . . . , BX OR(An))
 *			Note that, BAN D() and BX OR() represent the results of bitwise AND of bitwise XOR
 *			operations applied pairwise on a set of numbers, respectively. In case of a tie, return all the
 *			optimal results.
 * Language:  C
 */

#include <stdio.h>
#include <stdlib.h>

//Global vars declaration
int max =0;							// to store max value of all the partitons
int **a,x;							// a to store every partition.
int rows,*cols, *results;			// Number of rows, No. of columns for each row, result of each row.

void getPartitions(int *s, int n,int *arr) {				// function to generate all partitions of input numbers.
    
    int part_num = 1;
    int i;
    for (i = 0; i < n; ++i)
        if (s[i] > part_num)
            part_num = s[i];

    a[x] = (int *)malloc(2*(part_num + 4 )*sizeof(int));
    cols = (int *)realloc(cols, (x+1)*sizeof(int));
    results = (int *)realloc(results, (x+1)*sizeof(int));

    int p;
    int xor=0, and;
	cols[x] = 0;
    for (p = part_num; p >= 1; --p) {
    	if(p != part_num) {
        	*(*(a + x) + cols[x])= -1;
        	cols[x]++;
    	}
        //printf("{");
        xor =0;
        /* If s[i] == p, then i + 1 is part of the pth partition. */
        for (i = 0; i < n; ++i) {
            if (s[i] == p)
            {   
            	//printf("%d, ", arr[i]);
            	xor ^= arr[i];
            	*(*(a + x) + cols[x]) = arr[i];
            	cols[x]++;
     		}
        }
        //printf("\b\b} ");
        if(p == part_num) {
        	and = xor;
        }else {
        	and &= xor;
        }

    }

    //printf("    =  %d\n",and );
    results[x] = and;
    if(max < and) {
    	max =and;
    }
    //printf("\n");
}

int next(int *s, int *m, int n) {							//function to check for the boundary condition on generating partitions
    int i = 0;
    ++s[i];
    while ((i < n - 1) && (s[i] > m[i] + 1)) {
        s[i] = 1;
        ++i;
        ++s[i];
    }
 
    if (i == n - 1)											// If i is has reached n-1 th element, then the last unique partitiong has been found
        return 0;
 
    int max = s[i];											// Because all the first i elements are now 1, s[i] (i + 1 th element) is the largest. 
    														// So we update max by copying it to all the first i positions in m.
    for (i = i - 1; i >= 0; --i)
        m[i] = max;
 
    return 1;
}

int main() {
	int *arr = (int *) malloc(sizeof(int));
	int n = 0;
	int s[16]; 			// s[i] is the number of the set in which the ith element should go 
    int m[16]; 			// m[i] is the largest of the first i elements in s
 	char par;

 	printf("Enter positive integer numbers separeted by space.\n");

	do {												//dynamically allocating space to occupy input numbers separeted by spaces.
		arr = (int *) realloc(arr, (n+1)*sizeof(int));
		scanf("%d%c",&arr[n],&par);
		n++;
	} while (par != '\n');

	for(int i=0; i< n; i++) {        					//initializing s and m to 1
		s[i] = 1;
		m[i] = 1;
	}

	a = (int **)malloc(2*sizeof(int));					// 2D dynamic matrics to store partitions
	x = 0;
	rows = 0;											// no. of rows
	cols = (int *)malloc(sizeof(int));					// no. of columns
	results = (int *)malloc(sizeof(int));				// result array containing result of XOR and  AND of the partitions
	
    while (next(s, m, n)) {								//generating all partitions from input numbers.
    	a = (int **) realloc(a,(x+2)*sizeof(int *));
        getPartitions(s, n, arr);
        x++;
        rows++;
    }

    for (int i = 0; i < rows; i++)						// loop for printing partitions having maximun result for given function of XOR and AND
    {
    	if(results[i] == max) {
	        for (int j = 0; j < cols[i]; j++)
	        {
	            printf("%d ", *(*(a + i) + j));
	        }
			//printf("  =  %d",results[i] );
        	printf("\n");
    	}
    }
    printf("%d\n", max);								//	printing max

    for(int i=0;i<rows;i++){							// Freeing up all dynamically allocated memory
		free(a[i]);
	}
	free(a);

	free(cols);
	free(results);

	return 0;
}

