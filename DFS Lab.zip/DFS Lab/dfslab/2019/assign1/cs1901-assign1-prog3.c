/*
 * Author: Dipen Rana (CS1901)
 * Purpose: Suppose you are given with a sequence of n integers. Write a program that will find out a
 *			pair of indices i and j (j ≥ i) such that the sum of the values in the sub-sequence starting at
 *			index i and ending at index j (both inclusive) is maximum. Consider the starting index to be
 *			0. You need to output both the indices and the maximum value of summation. In case, there
 *			are multiple subsequences possible as the optimal answer, return the shorter subsequence. If
 *			there is a further tie return all the results
 * Language:  C
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
	int *arr = (int *) malloc(sizeof(int)),
		n=0;
	char num;
	int max_so_far, 
		max_ended_here, 
		sum_max, 
		index, 
		start =0, 
		end =0,
		s=0,
		len = 0;

	printf("Enter the elements in array\n");
	
	do {												// dynamic memory allocation to get input interger array.
		arr = (int *) realloc(arr, (n+1)*sizeof(int));
		scanf("%d%c", &arr[n], &num);
		n++;
	} while (num != '\n');

	max_ended_here = 0;
	max_so_far = arr[0];

	for(int i=0; i<n; i++) {     						//loop to compute max subsequence.
		max_ended_here += arr[i];

		if(max_so_far < max_ended_here) {
			max_so_far = max_ended_here;
			start = s; 
            end = i; 
		}

		if(max_ended_here < 0) {
			max_ended_here = 0;
			s = i + 1;
		}
	}

	len = end - start;									// length of shortest subsequence with max sum.
	sum_max = max_so_far;								// max sum of subsequence

	index = 0;

	max_ended_here = arr[0];

	if (max_ended_here == sum_max)
		printf("%d %d\n",index,0);

	for(int i=1; i<n;i++){								// loop to print multiple index ranges for the max subsequence sum.

		if (max_ended_here <= 0 ){
			index = i;	
		}
		max_ended_here += arr[i];

		max_ended_here = (max_ended_here > arr[i]) ? max_ended_here : arr[i] ;

		if (max_ended_here == sum_max && (i - index) == len){
			printf("%d %d\n", index, i );
			index = i+1;
			max_so_far = 0;
		}
	}

	printf("%d\n", sum_max );

	free(arr);   										// free dymnamically allocated merrory.

	return 0;
}