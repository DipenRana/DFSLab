/*
 * Author: Dipen Rana (CS1901)
 * Purpose: Suppose we define the angle between a pair of hands (denoting hour, minute, and second) of a 
 * 			clock as the lowest of the two possible angles. Let the hands are said to be in
 *			EQUIANGULAR position if the angles between them are the same. Further assume that
 *			the hands of a clock are said to be in SEMI-EQUIANGULAR position if the angles between		
 *			any two pairs of hands are the same. Write a program that takes time as the user input and
 *			returns whether the clock is in EQUIANGULAR, SEMI-EQUIANGULAR, or NONE of the
 *			above positions. Consider that there is a tolerance level to ensure whether a pair of angles
 *			are same or not. Given the two angles α and β, they are said to be same for a tolerance level
 *			δ if |α − β| ≤ δ.
 * Language:  C
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

float stringToFloat(char *string) // funtion to convert string to float.
{
    float result= 0.0;
    int len = strlen(string);
    int dotPosition = 0;
    int i;

    for (i = 0; i < len; i++)
    {
        if (string[i] == '.')
        {
          dotPosition = len - i  - 1;
        }
        else
        {
          result = result * 10.0 + (string[i]-'0');
        }
      }

      while (dotPosition--)
      {
        result /= 10.0;
      }

    return result;
}


int main() {
	int hr,min,sec,clk[3] = {0,0,0},i=0,j=0;
	char time[20],tol[8];
	double ang1,ang2,ang3, A1,A2,A3;
	double t, Tolerance;

	printf("Enter Time in HH:MM:SS format\n");
	scanf("%[^\n]s",time);

	while( i< strlen(time)) {
		if(time[i] == ' ' ){
			break;
		}

		if(time[i] != ':'){
			clk[j] = clk[j] * 10 + time[i] - 48;
		} else{
			j++;
			if(time[i+1] == ':') {
				printf("You entered time in wrong format.\n");
				return -1;
			}
		}
		i++;
	}

	j=0;
	i++;
	while( i< strlen(time)){
		tol[j] = time[i];
		i++;
		j++;
	}
	tol[j] = '\0';
	t = stringToFloat(tol);  // converting string to float

	hr = clk[0];	//hours
	min = clk[1];	//minutes
	sec = clk[2];	//seconds

	if(!(min >= 0 && min < 60) || !(sec >=0 && sec < 60) || t < 0){    //Min and sec format check
		printf("You Entered time/tolerance in wrong format.\n");
		return -1;
	}

	//printf("time= %d : %d : %d\n", hr, min, sec );

	ang1 = hr%12 * 30 + (min / 2.0) + sec/120.0;
	ang2 = min * 6 + sec / 10.0;
	ang3 = sec * 6;

	Tolerance = (double)(t * 180 * 7.0/ 22.0);

	A1 = (ang1 > ang2) ? ang1 - ang2 : ang2 - ang1;  //smaller angle btw H and M
	if (A1 > 180 ) {
		A1 = 360 - A1;
	}

	A2 = (ang1 > ang3) ? ang1 - ang3 : ang3 - ang1;  //smaller angle btw H and S
	if (A2 > 180 ) {
		A2 = 360 - A2;
	}

	A3 = (ang3 > ang2) ? ang3 - ang2 : ang2 - ang3;  //smaller angle btw M and S

	if (A3 > 180 ) {
		A3 = 360 - A3;
	}

    ang1 = (A1 > A2) ? A1-A2 : A2-A1; //diff btw 2 angles
    ang2 = (A1 > A3) ? A1-A3 : A3-A1; //diff btw 2 angles
    ang3 = (A2 > A3) ? A2-A3 : A3-A2; //diff btw 2 angles

    if (ang1<= Tolerance && ang2 <= Tolerance || ang1<= Tolerance && ang3 <= Tolerance || ang2<= Tolerance && ang3 <= Tolerance) {
    	printf("EQUIANGLAR\n");
    } else if (ang1<= Tolerance || ang2 <= Tolerance || ang3 <= Tolerance) {
    	printf("SEMI-EQUIANGLAR\n");
    } else {
    	printf("NONE\n");
    }

	return 0;
}