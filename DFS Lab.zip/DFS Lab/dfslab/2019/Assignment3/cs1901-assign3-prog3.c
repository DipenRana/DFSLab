/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 28-Oct-19
  Program description: Prog3 conflict serializability test.
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// structure defined to store the simplified input.
struct Input
{
  int p_id;
  int line_no;
  char opr;
  char data_item;
};

//function to check wheather the string is a number or not.
int isNumber(char *ch) {
    for(int i = 0; i < strlen( ch ); i ++)
   {
      if (ch[i] < 48 || ch[i] > 57)
         return -1;
   }
   return 1;
}


//comparator function used for sorting the input saved in combined var.
int comp(const void* a, const void* b) {
    struct Input *p1 = (struct Input *)a;
    
    struct Input *p2 = (struct Input *)b;

    return p1->line_no - p2->line_no;
}

// A recursive function that uses visited[] and parent to detect 
// cycle in subgraph reachable from vertex v. 
int isCyclicUtil(int **mat,int size, int v, int *visited, int *recStack) 
{ 
    if(visited[v] == 0)
    {
        visited[v] = 1;
        recStack[v] = 1;
 
        for(int i = 0; i < size; ++i)
        {
          if(mat[v][i] == 1)
          {
            if ( !visited[i] && isCyclicUtil(mat, size, i, visited, recStack) )
              return 1;
          else if (recStack[i])
           return 1;
          }
        }
    }
    recStack[v] = 0;  // remove the vertex from recursion stack
    return 0;
} 

// function to detect cycles. Returns true if the graph contains a cycle, else false. 
int isCyclic(int **mat, int size) 
{ 
    int visited[size]; 
    int recStack[size];
    for (int i = 0; i < size; i++) {
        visited[i] = 0;
        recStack[i] = 0;
    }
  
    for (int u = 0; u < size; u++) 
        if (!visited[u]) // Don't recur for u if it is already visited 
          if (isCyclicUtil(mat,size, u, visited, recStack)) 
             return 1; 
  
    return 0; 
} 

int main(int ac, char *av[]){
    FILE *fp[ac];     //array of file pointers
    int n; 
    char c[1000];
    int num_of_files = ac-1;
    int comb_size = 100;
    struct Input *combined = (struct Input *)malloc(comb_size*sizeof(struct Input));    //combined simplified input.
    int index = 0;

    int **matrix = malloc(num_of_files*sizeof(int));    // matrix defination and initialization to 0 for graph representation.
    for(int i =0; i<num_of_files; i++) {
      matrix[i] = malloc(num_of_files*sizeof(int));
      for (int j = 0; j < num_of_files; j++) 
        matrix[i][j] = 0;
    }

    for(int i = 0; i< ac-1; i++) {    //opening the file pointers.
        fp[i] =  fopen(av[i+1], "r");
    }


    int *lines_in_file = (int*)malloc(num_of_files*sizeof(int));  // To save number of lines in each input file.
    
    for (int i = 0; i < ac-1; i++)      //reading input from the file and saving that into the structure.
    {
      //printf("\n\n Input file no: %d\n", i+1);
      while(fgets (c, 100, fp[i])!=NULL) {
        //printf("%s", c);
        int line;
        if(line = isNumber(c) != -1){
            lines_in_file[i] = atoi(c);
            printf("lines of file = %d\n", atoi(c));
        }else if( (strstr(c,"read")) != NULL || (strstr(c,"write")) != NULL ) {
            char *p;
            if(index >= comb_size){
              combined = (struct Input *)malloc((2*comb_size)*sizeof(struct Input));
              comb_size *=2;
            }
            p = strtok (c," ()");
            combined[index].line_no = atoi(p);
            combined[index].p_id = i;
            p = strtok (NULL," ()");
            if(strcmp(p, "read") == 0){
              combined[index].opr = 'r';
            } else if(strcmp(p, "write") == 0) {
               combined[index].opr = 'w';
            }
            p = strtok (NULL," ()");
            combined[index].data_item = p[0];

           // printf("----%d. %c %c %d\n",combined[index].line_no,combined[index].opr,combined[index].data_item, combined[index].p_id);
            index++;
        }
      }
    }

    qsort(combined,index,sizeof(combined[0]), comp);

    for(int i = 0; i< ac-1; i++) {      // clossing all the file pointers.
        fclose(fp[i]);
    }

    // printing simplified version of input
/*   for (int i = 0; i < index; i++)
    {
      printf("----%d. %c %c %d\n",combined[i].line_no,combined[i].opr,combined[i].data_item, combined[i].p_id);
            
    }
*/
    // Prepraing the matrix representation of the precedence graph for the given input.
    for (int i = 0; i < index -1; i++)     
    {
      for (int j =  i+1; j < index; j++) {
        if(combined[i].opr == 'r'){
          if(combined[j].opr == 'w' && combined[j].data_item == combined[i].data_item && combined[j].p_id != combined[i].p_id)
            matrix[combined[i].p_id][combined[j].p_id] = 1;
        } else if(combined[i].opr == 'w') {
          if( combined[j].data_item == combined[i].data_item && combined[j].p_id != combined[i].p_id) {
            matrix[combined[i].p_id][combined[j].p_id] = 1;
          }
        }
      }
    }

/*   for (int i = 0; i < num_of_files; i++)   // printing the graph in matrix form.
    {
      for (int j = 0; j < num_of_files; j++)
        printf("    %d", matrix[i][j]);
      printf("\n");
    }
*/

    if( isCyclic(matrix, num_of_files)){    // Cycle is present in the graph
        printf("Not Conflict Serializable");
    } else {
        printf("Conflict Serializable");
    }

    free(combined);

    for (int i = 0; i < num_of_files; i++)
        free(matrix[i]);

    free(matrix);
  
    
    return 0;
}