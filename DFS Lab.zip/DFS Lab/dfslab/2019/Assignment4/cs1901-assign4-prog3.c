/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Prog3
  Acknowledgements:
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    

    return 0;
}