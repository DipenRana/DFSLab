/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 16-Aug-19
  Program description: Prog3
  Acknowledgements:
------------------------------------*/

#include <stdio.h>


int minSquares(int m, int n) {
  int x = 2;
  if(m ==0 || n == 0)
    return 0;

  int boxes,min,max;
  min = (m > n) ? n : m;
  max = (m > n) ? m : n;
  if(min == 1){
    return max;
  }

  while(x*2 <= min){
    x = x*2;
  }

  int remainder = max % x;
  boxes = max / x + minSquares(remainder,min) + minSquares(min - x, max - remainder);
  return boxes;
}

int main() {
  char c;
  int n,m;
  int spc =0;
  int num =0;

  printf("Enter N * M\n");

  do{
    scanf("%c", &c );
    if(c == ' '){
      spc++;
      switch (spc) {
        case 1:
                n = num;
                break;
        case 2:
                m = num;
                break;
      }
      num =0;
    } else if(c == '\n') {
          m = num;
          num = 0;
      } else {
        num = num * 10 + c - 48;
      }
  }while(c != '\n');

  printf("%d",minSquares(m,n) );

  return 0;
}
