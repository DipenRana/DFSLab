/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 16-Aug-19
  Program description: Prog2
  Acknowledgements:
------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

struct Testcase {
  int total;
  int counter;
  int rhym;
};

struct list{
  int p;
  struct list * ptr;
};

int main() {
  int n;
  char c;
  struct Testcase *tst;


  printf("Enter number of testcases\n" );
  scanf("%d",&n );

  tst = (struct Testcase *) malloc((n+1)* sizeof(struct Testcase));
  int spc;
  int num;
  for (int i = 0; i<= n ; i++ ) {
    spc = 0;
    num = 0;

    do{
      scanf("%c", &c );
      if(c == ' '){
        spc++;
        switch (spc) {
          case 1:
                  tst[i].total = num;
                  break;
          case 2:
                  tst[i].counter = num;
                  break;
          case 3:
                  tst[i].rhym = num;
                  break;
        }
        num = 0;
      } else if(c == '\n') {
          tst[i].rhym = num;
          num = 0;
      } else {
        num = num * 10 + c - 48;
      }
    }while(c != '\n');

  }

  printf("\n" );

  for(int j=1; j<=n; j++) {

  /*  printf("Test1 : %d %d %d\n", tst[j].total, tst[j].counter, tst[j].rhym );   */


    int tot = tst[j].total;
    struct list *head, *new, *temp;
    head = (struct list *) malloc(sizeof(struct list));
    head->p = 1;
    head->ptr = head;
    temp = head;

    for(int i = 1; i < tot; i++) {
      new = (struct list *) malloc(sizeof(struct list));    //Working for case 1, segmentation fault for case 2.
      new->p = i+1;
      new->ptr = head;
      temp->ptr = new;
      temp = new;
    }

    temp = head;



    while(head->p != tst[j].counter){
      head = head->ptr;
    }

    int cnt;
    tot = tst[j].total;
    while(tot != 0){
      cnt = 1;
      while(cnt != tst[j].rhym) {
        temp = head;
        head = head->ptr;
        cnt++;
      }
      temp->ptr = head->ptr;
      printf("%d ",head->p );
      temp = head;
      head = head->ptr;
      free(temp);
      tot--;
    }
    printf("\n" );
    free(head);
    free(new);
    free(temp);

  }

free(tst);

return 0;
}
