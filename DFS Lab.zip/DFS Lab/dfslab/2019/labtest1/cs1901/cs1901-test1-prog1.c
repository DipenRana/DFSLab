/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 16-Aug-19
  Program description: Prog1
  Acknowledgements:
------------------------------------*/
#include<stdio.h>
#include<stdlib.h>

int main() {
  int *length, *freq;
  int n = 0,
      len =0,
      count =0,
      i = 0;
  char *chptr = (char *) malloc(sizeof(char));
  char c;
  int max,index =0;

  length = (int *) malloc(sizeof(int));
  freq = (int *) malloc(sizeof(int));

  printf("Enter the string\n" );

  do {
    c = getchar() ;
    i++;
    chptr = (char *) realloc(chptr, (i+1)*sizeof(char));
    chptr[i] = c;
    if(c >= 'a' && c <= 'z' || c >= 'A' && c <='Z'){
      len++;
    } else if(len != 0)
    {
      int ind = -1;
      for (int i=0; i<n; i++){
        if( len == length[i]) {
          ind = i;
          break;
        }
      }
      if ( ind == -1){
        length = (int *) realloc(length, (n+1)*sizeof(int));
        freq = (int *) realloc(freq, (n+1)*sizeof(int));
        length[n] = len;
        freq[n] = 1;
        n++;
      } else {
        freq[ind] += 1;
      }

      len = 0;
    }

  } while(c != EOF) ;

  max =0;
  for(int i=0; i<n; i++) {
    /*printf("length = %d , freq = %d\n", length[i], freq[i] ); */
    if(freq[i] > max){
      index = i;
      max = freq[i];
    }
  }

  if(n == 0)
    printf("0 0");
  else
    printf("%d %d\n", length[index], freq[index] );

  free(length);
  free(freq);

  return 0;
}
