#include<stdio.h>
#include<stdlib.h>
#include <stdbool.h>
#include <stddef.h>

typedef struct {
  void *elements;
  size_t elements_size, num_elements, max_elements;
}STACK;

STACK newStack(int element_size);
void initStack (STACK *s, int element_size);
void freeStack(STACK *s);
bool isEmpty(const STACK *s);
void push(STACK *s, const void *eptr);
void pop(STACK *s, void *eptr);
