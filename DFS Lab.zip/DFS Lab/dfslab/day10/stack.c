#include "stack.h"
#include<stdbool.h>
#include <string.h>
static int top = -1;
#define MAX 10

void initStack(STACK *s, int elem_size) {
    s->elements = (void *) malloc(elem_size);
    s->num_elements = 0;
    s->max_elements = MAX;
}

bool isEmpty(const STACK *s) {
    if(s->num_elements == 0)
      return true;
    else
      return false;
}

void freeStack(STACK *s) {
  free(s);
}

void push(STACK *s, const void *eptr) {

    if(s->num_elements==s->max_elements) {
      printf("Stack Overflow\n" );
    } else {
      s->elements = (void *) realloc(s->elements, s->elements_size* s->num_elements);
      void *a = &s + s->elements_size * s->num_elements;
      memmove(a, eptr, s->elements_size);
      s->num_elements++;
      //printf("%ld\n",s->num_elements );
    }
}

void pop(STACK *s, void *eptr) {

  if(s->num_elements == 0){
    printf("Underflow\n" );
    return;
  }
  void *top = &s + s->elements_size * s->num_elements;
  eptr = top;
  printf("TOP = %u\n",top );
  s->num_elements--;
}

int main() {
    STACK *s= (STACK *)malloc(sizeof(STACK));
    initStack(s, 4);

    if(isEmpty(s)) {
      printf("Empty\n" );
    } else {
      printf("NOT Empty\n" );
    }

    int a =10;
    int *p = &a;
    push(s,p);

    if(isEmpty(s)) {
      printf("Empty\n" );
    } else {
      printf("NOT Empty\n" );
    }
    int *poped;
    pop(s,poped);
    printf("Popped = %ls\n",poped );

    return 0;
}
