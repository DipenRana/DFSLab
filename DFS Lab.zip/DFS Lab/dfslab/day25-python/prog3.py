import sys


b= []

n = int(input("Enter number of lines"))

for i in range(0,n-1,1):
	x = ''
	k = 0
	while k <= n-1:
		x = x + ' '
		k = k+1
	for j in range(0,n+i,1):
		if (j <= n+i-1 and j>= n-i-1):
			x = x + '*'
		else:
			x= x + ' '
	print(x)

for i in range(n,0,-1):
	x = ''
	k = 0
	while k >=-1:
		x = x + ' '
		k = k-1
	for j in range(i,0,-1):
		if (j == 1 and i != 1):
			x = x + ' '
		if (i == j) or (j == 1):
			x= x + '*'

		else:
			x= x + '  '
	print(x)



#while (1):
#	x = sys.stdin.readline()
#	if(x[0] == '\n'):
#		break
#	b.extend(x[:-1].split(" "))
#	print(b)
