'''-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Prog1 Winning pair of the bitwise XOR for  the ages of them.
  Acknowledgements:
------------------------------------
'''

names = []

try:                       # getting input
    while True:
        k = input()
        s = k.split()
        names.append(s)
except EOFError:          # reading until eof is entered
    pass

max_value = -1
count = 0
index1 = -1
index2 = -1

for i in range(len(names)):         # calculating the XOR value for each pairs
    for j in range(i+1, len(names)):
        xor = int(names[i][1]) ^ int(names[j][1])
        if  xor == max_value:
            count += 1          #Keeping track of number of pairs having maximum XOR value
        elif xor > max_value:
            max_value=xor
            index1=i
            index2=j
            count = 1

if count > 1:           # if there are more than one pair having max XOR value
    print("TIE")
else:
    if int(names[index1][1]) < int(names[index2][1]):       # printing names in lexicographical order
        print(names[index1][0]+" "+names[index2][0])
    else:
        print(names[index2][0]+" "+names[index1][0])
