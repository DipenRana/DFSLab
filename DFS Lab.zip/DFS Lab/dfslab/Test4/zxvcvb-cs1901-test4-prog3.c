/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Prog3 BST Tree: Printing path of maximum turn and min path length.
  Acknowledgements:
------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

struct node         // Structure of node of the tree
{
  int data;
  struct node *left;
  struct node *right;
  struct node *parent;
};

struct node* newNode(int data,struct node* p)   // creating new node
{
  struct node* node = (struct node*)malloc(sizeof(struct node));
  node->data = data;
  node->left = NULL;
  node->right = NULL;
  node->parent=p;
  return(node);
}

int comp(const void* a, const void* b) {    // comparator function for integers
    int *p1 = (int *)a;
    int *p2 = (int *)b;

    return *p1 - *p2;
}

int search(int arr[], int strt, int end, int value)   // searching for the value in the array(in order)
{
  int i;
  for (i = strt; i <= end; i++) {
      if (arr[i] == value)
          return i;
  }
}

struct node* buildTree(int in[], int pre[], int inStrt, int inEnd, struct node *ptr) {    // Building bst given the Inorder and the preorder
    static int preIndex = 0;

    if (inStrt > inEnd)
        return NULL;

    struct node* tNode = newNode(pre[preIndex++],ptr);
    if (inStrt == inEnd)
        return tNode;
    int inIndex = search(in, inStrt, inEnd, tNode->data);
    tNode->left = buildTree(in, pre, inStrt, inIndex - 1, tNode);
    tNode->right = buildTree(in, pre, inIndex + 1, inEnd, tNode);

    return tNode;
}


int height(struct node* node)     // calculating the height of the tree
{
    if (node==NULL)
        return 0;
    else
    {
        /* compute the height of each subtree */
        int lheight = height(node->left);
        int rheight = height(node->right);

        /* use the larger one */
        if (lheight > rheight)
            return(lheight+1);
        else return(rheight+1);
    }
}


void printGivenLevel(struct node* root, int level)      // function for printing the level order of the tree
{
    if (root == NULL){
      printf("X  " );
      return;
    }
    if (level == 1)
        printf("%d ", root->data);
    else if (level > 1)
    {
        printGivenLevel(root->left, level-1);
        printGivenLevel(root->right, level-1);
    }
}


void printLevelOrder(struct node* root)           // function for printing the level order of the tree
{
    int h = height(root);
    int i;
    for (i=1; i<=h; i++)
        printGivenLevel(root, i);
}

int calculateTurn(struct node* node, int *len){     // calculating the turn value and length of the path for the node
    int turn = 0;
    struct node *parent = NULL;
    struct node *grand_parent = NULL;

    if(node->parent != NULL && node->parent->parent != NULL)
    {  parent = node->parent;
        grand_parent = node->parent->parent;
    } else
      return 0;

    *len = 2;

    while( parent != NULL && grand_parent != NULL) {
        if(grand_parent->left == parent) {
          if(parent->right == node)
            turn++;
        }
        if (grand_parent->right == parent) {
          if(parent->left == node)
            turn++;
        }

        if(grand_parent->parent == NULL)
          return turn;

        node = parent;
        parent = grand_parent;
        grand_parent = grand_parent->parent;
        (*len)++;
    }

    return turn;
}

int maxturn = 0, minlen = 0;

void treeInorder(struct node* node)       // calculating the path having maximum turn value and min path length for every leaf node
{
     if (node == NULL)
          return;
     treeInorder(node->left);
     if(node->left == NULL && node->right == NULL){
       int length = 0;
       int turn = calculateTurn(node, &length);

       if(turn == maxturn && length < minlen)
         minlen = length;
       else if( turn > maxturn){
          maxturn = turn;
          minlen = length;
        }
       //printf("%d  Turn:%d  len: %d\n",node->data, turn , length);
     }
     treeInorder(node->right);
}

void nodePrint(struct node* node){      // priting the path starting from the root to the leaf.
  if(node->parent != NULL)
    nodePrint(node->parent);

  if(node->right == NULL && node->right == NULL)
    printf("%d",node->data );
  else
    printf("%d-",node->data );
}


void printPaths(struct node* node)    // calculating the turn value and length of the path for the node
{
     if (node == NULL)
          return;
     printPaths(node->left);
     if(node->left == NULL && node->right == NULL){
       int length = 0;
       int turn = calculateTurn(node, &length);

       if(turn == maxturn && length == minlen){
         nodePrint(node);
         printf("\n%d\n", length );

       }
     }
     printPaths(node->right);
}

void freeTree(struct node* node){   // freeing up the dynamically allocated memory to the tree nodes.
    if (node == NULL)
       return;
    freeTree(node->left);
    freeTree(node->right);
    free(node);
}


int main() {
  int n;
  int *pre, *in;
  char c;

  printf("Enter number of nodes:\n" );
  scanf("%d", &n );
  pre = (int *)malloc(n*sizeof(int));       // preorder traversal entered by the user
  in = (int *)malloc(n*sizeof(int));

  int k;
  for (int k = 0; k < n; k++) {
    scanf("%d%c", &pre[k],&c);
    in[k] = pre[k];
    if(c == '\n' && k < n-1){
      printf("Invalid input entered\n" );
      return 0;
    }
  }

  // printf("pre order:\n");
  // for (int i = 0; i < n; i++) {
  //   printf("%d ",pre[i] );
  // }

  qsort(in, n, sizeof(int), comp);    // Inorder travelsal of the BST is the sorted order of the values of its nodes.

  // printf("\nIn order:\n");
  // for (int i = 0; i < n; i++) {
  //   printf("%d ",in[i] );
  // }

  struct node *root;

  root = buildTree(in, pre , 0, n-1, NULL);       // building the tree from the Inorder and the preorder.

  // printf("\n\n\n");
  //
  // printLevelOrder(root);

  minlen = n;

  treeInorder(root);      // here we are calculating the max turn value and min length value.

  //printf("maxturn: %d  minlen: %d\n", maxturn, minlen );

  printPaths(root);     // printing the required paths.

  freeTree(root);       // FREEING up the space.

  return 0;
}
