/*-----------------------------------
  Name: Dipen G Rana
  Roll number: CS1901
  Date: 08-Nov-19
  Program description: Prog2 Generic code to get values between the given range
  Acknowledgements:
------------------------------------*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int compare_int(const void *p, const void *q)     // comparator function for integers
{
    int l = *(const int *)p;
    int r = *(const int *)q;

    return (l-r);
}

int compare_float(const void *p, const void *q)  // comparator function for integers
{
    float l = *(const float *)p;
    float r = *(const float *)q;

    return ((l>r)-(l<r));
}

int compare_char (const void *a, const void * b)  // comparator function for integers
{
  return ( *(char *)a - *(char *)b );
}

int main(int argc, char **argv)
{
    FILE *fptr;
    fptr = fopen(argv[1], "r");       // file pointer for reading the file.

    char *lb = argv [2];      // upper bound
    char *ub = argv [3];      // lower bound
    char *type = argv[4];     // type

    int range = 0;
    fscanf(fptr,"%d ",&range);

    if(type[0] == 'i') {           //**************  input is given as integer
        int *array = (int *)malloc(100 * sizeof(int));
        int in=0;

        int lower=0,upper=0;
        int len = strlen(lb);
        for(int i=0;i<len;i++) {
          lower=(lower*10)+(lb[i]-'0');
        }

        len = strlen(ub);
        for(int i=0;i<len;i++) {
          upper=(upper*10)+(ub[i]-'0');
        }
        in = fscanf(fptr,"%d ",&array[0]);

        for(int i =1;i<range;i++) {
          in = fscanf(fptr,"%d ",&array[i]);  // reading the integer values from file
        }

        qsort((void*)array,range, sizeof(array[0]), compare_int);     // sorting the input

        for(int i = 0;i<range;i++) {        // printing the values between the range
          if(array[i]>=lower && array[i]<=upper)
           printf("%d ",array[i]);
          if(array[i]>upper)
           break;
        }
    } else if(type[0] == 'c') {         //******* input is given as charcter
        char *array = (char *)malloc(100 * sizeof(int));
        int in=0;
        char low=lb[0];
        char up=ub[0];

        in = fscanf(fptr,"%c ",&array[0]);

        for(int i =1;i<range;i++) {
          in = fscanf(fptr,"%c ",&array[i]);    // reading the charcter values from file
        }

        qsort((void*)array,range, sizeof(array[0]), compare_char);    // sorting the input

        for(int i = 0; i<range ;i++) {          // printing the values between the range
          if(array[i]>=low && array[i]<=up)
           printf("%c ",array[i]);
          if(array[i]>up)
           break;
        }
    } else if(type[0] == 'r') {                 //******** input is given as reals
        float *array = (float *)malloc(100 * sizeof(int));
        int in=0;
        float lower=0,upper=0;
        int flag=0;
        int len = strlen(lb);
        float k =0.1;
        for(int i=0;i<len;i++) {
          if(lb[i]=='.') {
            flag = 1;
            continue;
          }
          if(flag==0) {
           lower=(lower*10)+(lb[i]-'0');
          }
          else {
            lower=lower+k*(lb[i]-'0');
            k=k*0.1;
          }
        }

        len = strlen(ub);
        k =0.1;
        flag = 0;

        for(int i=0;i<len;i++) {
          if(ub[i]=='.') {
            flag=1;
            continue;
          }
          if(flag==0)
            upper=(upper*10)+(ub[i]-'0');
          else {
            upper=upper+k*(ub[i]-'0');
            k=k*0.1;
          }
        }

        in = fscanf(fptr,"%f ",&array[0]);

        for(int i =1;i<range;i++){
          in = fscanf(fptr,"%f ",&array[i]);    //reading the input
        }

        qsort((void*)array,range, sizeof(array[0]), compare_float);     // sorting the input

        for(int i = 0;i<range;i++) {              // printing the values between the range
          if(array[i]>=lower && array[i]<=upper)
            printf("%f ",array[i]);
          if(array[i]>upper)
            break;
         }
    }

  return 0;
}
