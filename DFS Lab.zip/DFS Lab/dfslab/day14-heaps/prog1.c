#include<stdio.h>
#include<stdlib.h>

// typedef struct {
//   size_t ele_size;
//   unsigned int num_alloc, num_used;
//   void *arr;
//   int comparator(void *,int , int);
// }HEAP;

void Heapify(float *arr, int i , int size) {

  int flag;
  float  lc = 0,rc = -1,par, max;
    rc =-1;
  if(2*i+1 <= size){
    rc = arr[2*i+1];
    lc = arr[2*i];
    flag =1;
  }else{
    lc = arr[2*i];
    flag = 0;
  }

    par = arr[i];
    max = par;
  if(par < lc){
    max = lc;
    arr[2*i] = par;
    arr[i] = max;
    if(2*i <= size/2)
      Heapify(arr,2*i,size);
  }
  par = arr[i];
  if(par < rc && flag){
    max = rc;
    arr[2*i+1] = par;
    arr[i] = max;
    if(2*i+1 <= size/2)
      Heapify(arr,2*i+1,size);
  }
}

int delete(float *arr,int size, int *p, int i) {
  float x;
  x=arr[1];
  arr[1] = arr[size];
  Heapify(arr, 1, size-1);
  printf("%f\n",x );
  if(x == arr[1])
    p[i]++;
  return size-1;

}

int main() {

  int size,flag;
  float *arr, lc = 0,rc = -1,par, max;

  printf("Enter size of heap\n" );
  scanf("%d", &size );

  arr = (float *)malloc((size+1)*sizeof(float));

  for(int i = 1; i<=size; i++) {
    scanf("%f", arr+i);
  }

  for(int i = size/2; i>=1 ; i-- ){

    Heapify(arr,i, size);
  }
  int j =1,ar=1;

  for(int i =1; i <= size; i++) {
    printf("   %f  ",arr[i] );
    if(i==ar){
      printf("\n" );
      j = j*2;
      ar = ar+j;
    }
  }

  printf("Top three probs are.\n" );
  int *p[3];
for(int i =0; i<3; i++) {
  
  size = delete(arr, size,p,i);
}
  size = delete(arr,size);
  size = delete(arr, size);
  return 0;
}
