#include <stdlib.h>
#include <stdio.h>
#include "bst.h"

#define Malloc(i,type) (type *) malloc((unsigned)(i*sizeof(type)));

extern int compare(NODE *n, DATA d) {
  if (n->data > d)
    return -1;
  else if (n->data < d)
    return 1;
  else
    return 0;
}

extern void inorder(NODE *root) {
  if(root != NULL) {
    inorder(root->left);
    printf("%d\n", root->data);
    inorder(root->right);
  }
}


//extern void print_tree(NODE *root,int indent);
//extern void print_pstree(NODE *root);


extern NODE *insert(NODE *root, DATA d) {

  if(root == NULL) {
    root = Malloc(1, NODE);
    root->data = d;
    root->left = root->right = NULL;
    return root;
  }

  int cmp = compare(root,d);
  if(cmp < 0)
      root->left = insert(root->left,d);
  else if(cmp > 0)
      root->right = insert(root->right,d);

  return root;
}


extern NODE *detach_successor(NODE *node) {
  NODE *nptr;

  nptr = node->right;
  if (nptr == NULL)
    return NULL;
  if (nptr->left == NULL) {
    node->right = nptr->right;
    return node;
  }

  while (nptr->left !=NULL) {
    node = nptr;
    nptr = nptr->left;
  }

  node->left = nptr->right;
  return nptr;
}

void delete(NODE **nodeptr, DATA d) {
  NODE *node, *s;

  node = *nodeptr;
  if (node == NULL) return;

  int cmp = compare(node,d);
  if(cmp < 0) delete(&(node->left), d);
  else if(cmp > 0) delete(&(node->right), d);
  else {
    if(node->left == NULL && node->right == NULL) {
      *nodeptr = NULL;
      free(node);
      return;
    }
    if(node->left == NULL) {
      *nodeptr = node->right;
      free(node);
      return;
    }
    if(node->right == NULL) {
      *nodeptr = node->left;
      free(node);
      return;
    }

    s = detach_successor(node);
    node->data = s->data;
    free(s);
  }
  return;
}

int main()
{

  NODE *root = NULL;

  root = insert(root, 5);
  root = insert(root, 35);
  root = insert(root, 15);
  root = insert(root, 25);

  inorder(root);

  return 0;
}
