/*-----------------------------------
Name: Anoop Kumar
Roll number: CS1921
Date: 11/10/2019
Program description: Assignment 2 Program 2
Acknowledgements:
------------------------------------*/


#include<stdio.h>
#include<string.h>


int main()
{
    float prob=0;
    char P[2][20],Ch[2][25];
    int L_P[2],L_C[2];
    int A,B,C,D;
    int x = 0 ,y = 0;
    //input
    scanf("%f %s %s %s",&prob,&P[0],&P[1],&Ch[0]);
    
    L_P[0]=strlen(P[0]);
    L_P[1]=strlen(P[1]);
    L_C[0]=strlen(Ch[0]);

    if((L_P[0]+L_P[1])!= L_C[0])
    {
        scanf("%s",&Ch[1]);
        L_C[1]=strlen(Ch[1]);
    }
    else
    {
        strcat(P[1],P[0]);
        int k = strcmp(P[1],Ch[0]);
        if(k==0)
        {
            printf("0 %d",L_P[1]);
            return 0;
        }
        else
        {
            printf("INFEASIBLE");
            return 0;
        }
    }

    //checking feasibilty on probability
        int l =strcmp(P[1],Ch[1]);
        int m =strcmp(P[0],Ch[0]);
        
        if((!(prob > 1) && !(prob < 1)) && ((l==0)&&(m==0)))
        {
            printf("INFEASIBLE");
            return 0;
        }
        else if((!(prob > 0) && !(prob < 0))&& ((l!=m)))
        {
            printf("INFEASIBLE");
            return 0;
        }

    //Checking if total length of parents equal to total children length
    if((L_P[0]+L_P[1])!=(L_C[0]+L_C[1]))
    {
        printf("INFEASIBLE");
        return 0;
    }
    
    // calculating x i.e. common character in child 1
    for(int i = 0;i<L_P[0];i++)
    {
        if(P[0][i]==Ch[0][i])
            x++;
        else
            break;
    }

    // calculating y i.e. common character in child2
    for(int i = 0;i<L_P[1];i++)
    {
        if(P[1][i]==Ch[1][i])
            y++;
        else
            break;
    }
    
    // assigning values to A B &  C D considering parents as AB & CD and Children as AD & CB 
    if(x>y)
    {
        B = L_C[1]-y;
        A = L_P[0] - B;
        D= L_C[0]-A;
        C = L_P[1] - D;
    }
    else
    {
        D = L_C[0]-x;
        C = L_P[1] - D;
        B= L_C[1]-C;
        A = L_P[0] - B;
    }

    //feasibility tests
    //Checking Elements 
    int a = strncmp(P[0],Ch[0],A);
    int c = strncmp(P[1],Ch[1],C);
    int b = strncmp(P[0]+A,Ch[1]+C,B);
    int d = strncmp(P[1]+C,Ch[0]+A,D);

    if(((a) || (b)) ||((c)||(d)))
    {
        printf("INFEASIBLE");
        return 0;
    }
    
    printf("%d %d",A,C);
    return 0;
}