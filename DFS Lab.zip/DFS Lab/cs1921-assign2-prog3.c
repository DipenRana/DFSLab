/*-----------------------------------
Name: Anoop Kumar
Roll number: CS1921
Date: 11/10/2019
Program description: Assignment 2 Program 3
Acknowledgements:
------------------------------------*/
#include<stdio.h>
#define MAX 500

int main()
{                                // read the input and store it long int the array
  long int size1 = 0, size2 = 0;
  long int List1[250], List2[250];
  char c='a';
  
  do{
    scanf("%d%c", &List1[size1],&c);
    size1++;
  }while(c!='\n');
  do {
    scanf("%d%c", &List2[size2],&c);
    size2++;
  }while(c!='\n');
  
  long int arr1[MAX] = {0}, arr2[MAX] = {0};
  
  long int k1 = 0;
  while(List1[0] > 0){
    long int remainder1;
    remainder1 = List1[0]%10;
    arr1[k1] = remainder1;
    List1[0] = List1[0]/10;
    k1++;
  }

  long int p1;
  
  for(p1 = 1; p1 < size1; p1++)
  {
    long int L1, carry1 = 0;
    for(L1 = 0;L1 < k1; L1++)
    {
      long int temp1;
      temp1 = arr1[L1] * List1[p1] + carry1;
      arr1[L1] = temp1%10;
      carry1 = temp1/10;
    }
        
    while(carry1>0)
    {
      long int remainder1;
      remainder1 = carry1%10;
      arr1[k1] = remainder1;
      carry1 = carry1/10;
      k1++;
    }
  }
  // To view product 1
  long int s1;
     printf("prod1=");
     for(s1 = k1-1; s1 >= 0; s1--)
     printf("%d", arr1[s1]);
     printf("\n");


  long int k2=0;

  while(List2[0]>0)
  {
    long int remainder2;
    remainder2 = List2[0]%10;
    arr2[k2] = remainder2;
    List2[0] = List2[0]/10;
    k2++;
  }

  long int p2;
  for(p2 = 1; p2 < size2; p2++)
  {
    long int L2, carry2 = 0;
    for(L2 = 0; L2 < k2; L2++)
    {
      long int temp2;
      temp2 = arr2[L2]*List2[p2] + carry2;
      arr2[L2] = temp2%10;
      carry2 = temp2/10;
    }
    while(carry2 > 0)
    {
       long int remainder2;
       remainder2 = carry2%10;
       arr2[k2] = remainder2;
       carry2 = carry2/10;
       k2++;
    }
  }
  
// To view product 2
  long int s2;
  printf("prod2=");
  for(s2 = k2-1; s2 >= 0; s2--)
  printf("%d", arr2[s2]);
  printf("\n");


  if(k1 > k2)
    printf("L1");
  else if(k1 < k2)
    printf("L2");
  else
  {
     long int m = k1;
  
     while((arr1[m] == arr2[m]) && (m>=0))
     {
       m--;
     }
  
  if(m == -1)
    printf("L1 L2");
  else
    {
     if(arr2[m] > arr1[m])
       printf("L2");
     else
       printf("L1");
     }
  }
   return 0;
}
